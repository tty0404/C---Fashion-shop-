﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ICT711_Day1
{
    public static class MyArrays
    {
        public static int[] createIntArray()
        {
            //throw new Exception("Not Implemented");
            return new int[] { 5, 3, 2 }; 

        }

        public static char createStringArray(int index)
        {
            //throw new Exception("Not Implemented");
            //string is an array
            string str_var = "Done";
            return str_var[index];
          
        }

        public static int getSumOfArray(int[] array)
        {
            //throw new Exception("Not Implemented");
            int i = 0;
            int sumArray = 0;
            while (i < array.Length)
            {
                 sumArray += array[i];
                 i++;
            }
            return sumArray;
        }

        public static double getAverageOfArray(int[] array)
        {
            //throw new Exception("Not Implemented");
            int i = 0;
            double sumArray = 0;
            double averageArray = 0;
            while (i < array.Length)
            {
                sumArray += array[i];
                i++;
                averageArray = sumArray / array.Length;
            }
            return averageArray;
        }

        public static int [] sortIntArray(int[] array)
        {
            // Hint: use 2 nested for Loops to have 2 indexes. 
            // In the inner for loop, swap the 2 index values if the second one is smaller than the first one

            //throw new Exception("Not Implemented");
            
            for (int i = 0; i < array.Length - 1;i++)
            {
              
                for(int k = 0; k < array.Length-i-1; k++)
                if (array[k] > array[k+1]){
                    int num = array[k];
                    array[k] = array[k+1];
                    array[k+1] = num;
                }
            }
            return array;
        }
    }
}
