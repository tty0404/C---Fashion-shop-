﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace ICT711_Day1
{
    public class MyFiles
    {
        public static void createTextFile()
        {
            
            FileStream fs = new FileStream("data.txt", FileMode.Create, FileAccess.Write);
            StreamWriter sr = new StreamWriter(fs);
            sr.Write("Hello world!!");
            sr.Close();
            return;
            //throw new Exception("Not Implemented");
        }

        public static void createAndWriteTextInFile(string textToWrite)
        {
            //throw new Exception("Not Implemented");
            FileStream fs = new FileStream("newdata.txt", FileMode.Append, FileAccess.Write);
            StreamWriter sr = new StreamWriter(fs);
            sr.WriteLine(textToWrite);
            sr.Close();
            return;
        }
    }
}
