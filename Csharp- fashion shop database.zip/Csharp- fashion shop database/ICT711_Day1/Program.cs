﻿using System;

namespace ICT711_Day1
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
        
        
    }
}
