﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ICT711_Day1;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace ICT711_Day1.Tests
{
    [TestClass()]
    public class MyArraysTests
    {
        [TestMethod()]
        public void createIntArrayTest()
        {
            // Instructions
            // In MyArrays.cs -> createIntArray()
            // Create a new Integer Array. Fill-up the array with the values: 5, 3, 2
            // Return the new array

            int[] expected = { 5, 3, 2 };
            int[] actual = MyArrays.createIntArray();

            Assert.IsTrue(expected.SequenceEqual(actual));
        }

        [TestMethod()]
        public void createStringArrayTest()
        {
            // Instructions
            // In MyArrays.cs -> createStringArray()
            // Create a new String variable. Fill-up the variable with the word "Done!".
            // Return the character at the given index

            char expected = 'o';
            char actual = MyArrays.createStringArray(1);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void getSumOfArrayTest()
        {
            // Instructions
            // In MyArrays.cs -> getSumOfArray()
            // Calculate the sum of all array values
            // Return the calculate sum

            int expected = 10;
            int actual = MyArrays.getSumOfArray(new int[] { 5, 3, 2});

            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void getAverageOfArrayTest()
        {
            // Instructions
            // In MyArrays.cs -> getSumOfArray()
            // Calculate the average of all array values
            // Return the calculate value

            double expected = 10/3.0;
            double actual = MyArrays.getAverageOfArray(new int[] { 5, 3, 2 });

            Assert.AreEqual(expected, actual, 0.0001);
        }
        [TestMethod()]
        public void sortIntArrayTest()
        {
            // Instructions
            // In MyArrays.cs -> sortIntArra()
            // sort the array ascending 
            // Return the sorted array

            int [] expected = { 2, 3, 5};
            int[] actual = MyArrays.sortIntArray(new int[] { 5, 3, 2 });

            Assert.IsTrue(expected.SequenceEqual(actual));
        } 
    
    
    
    }   
}