﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ICT711_Day1;
using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace ICT711_Day1.Tests
{
    [TestClass()]
    public class MyFilesTests
    {
        [TestMethod()]
        public void createTextFileTest()
        {
            /// Instructions
            // In MyFiles.cs -> createTextFile()
            // Create a text file named: data.txt
            // Open the file and write in it "Hello world!!"
            // Make sure to close the file

            string expected = "Hello world!!";
            MyFiles.createTextFile();
            FileStream fs = new FileStream("data.txt", FileMode.Open, FileAccess.Read);
            StreamReader sr = new StreamReader(fs);
            string actual = sr.ReadLine();
            sr.Close();
            Assert.AreEqual(expected, actual);
        }

        
        [TestMethod()]
        public void createAndWriteTextInFileTest()
        {
            /// Instructions
            // In MyFiles.cs -> createAndWriteTextInFile()
            // Create a text file named: newdata.txt
            // The method should accept a text
            // You should write this text at the end of the file in a new line (append)
            // Make sure to close the file after writing to it

            string expected1 = "First Sentence.";
            string expected2 = "Second Sentence.";
            System.IO.File.Delete("newdata.txt");   // Delete the file
            MyFiles.createAndWriteTextInFile(expected1);
            MyFiles.createAndWriteTextInFile(expected2);
            FileStream fs = new FileStream("newdata.txt", FileMode.Open, FileAccess.Read);
            StreamReader sr = new StreamReader(fs);
            string actual1 = sr.ReadLine();
            string actual2 = sr.ReadLine();
            sr.Close();
            Assert.AreEqual(expected1, actual1);
            Assert.AreEqual(expected2, actual2);

        }
    }
}