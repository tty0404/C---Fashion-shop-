﻿using System;
using System.Buffers;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

namespace ICT711_Day2
{
    public static class My2DArrays
    {
        /// <summary>
        /// Calculates the multiplication of any number of input integers
        /// </summary>
        /// <param name="values">Any number of integers</param>
        /// <returns>The multiplication results</returns>
        public static int Multiply(params int[] values)
        {
            //throw new Exception("Not Implemented");
            int i = 0;
            int multiplyNum = 1;
            while (i < values.Length) {

                multiplyNum *= values[i]; 
             i++;
            }
            return multiplyNum;
       
        }
        /// <summary>
        /// Calculates the sum of a subset of the array elements
        /// </summary>
        /// <param name="rng">A range variable to calculate the sum over it</param>
        /// <param name="array">The input int array</param>
        /// <returns>Sum of the given range</returns>
        public static int CalculateRangeSum(Range rng, int[] array)
        {           
            return array[rng].Sum();
        }
        /// <summary>
        /// Creates 2D int array with a preset values
        /// </summary>
        /// <returns>2D int array</returns>
        public static int[,] CreateInt2DArray()
        {
            //throw new Exception("Not Implemented");
            int[,] array = { { 5, 2, 1 }, { 7, 9, 8 }, { 3, 4, 6 } };
            return array;
        }
        /// <summary>
        /// Creates 2D jugged string array with a preset values
        /// </summary>
        /// <returns>2D jugged string array</returns>
        public static string[][] CreateString2DArray()
        {
            //throw new Exception("Not Implemented");
            string[][] array = { new [] { "Monday", "3 sold","3","2","7"},
                                 new []{"Tuesday","2 sold","9","2"}, 
                                 new [] {"Wednesday", "0 sold" },
                                 new [] {"Thursday", "Holiday"},
                                 new [] {"Friday", "Holiday"}
                                };
            return array;
        }
        /// <summary>
        /// Calculates the sum of elements for the given column index
        /// </summary>
        /// <param name="array">2D int array</param>
        /// <param name="columnIndex">Target column index to calculate its sum</param>
        /// <returns>the sum of the target column</returns>
        public static int GetSumOfColumn2DArray(int[,] array, int columnIndex)
        {
            //throw new Exception("Not Implemented");
            int colu_sum = 0;
            
            for (int i = 0;i < array.GetLength(0); i++)
            {
                colu_sum += array[i,columnIndex];
            }
            return colu_sum;
        }
        /// <summary>
        /// Calculates the sum of elements for the given row index
        /// </summary>
        /// <param name="array">2D int array</param>
        /// <param name="rowIndex">Target row index to calculate its sum</param>
        /// <returns>the sum of the target row</returns>
        public static int GetSumOfRow2DArray(int[,] array, int rowIndex)
        {
            //throw new Exception("Not Implemented");
            int row_sum = 0;

            for (int i = 0; i < array.GetLength(1); i++)
            {
                row_sum += array[rowIndex,i];
            }
            return row_sum;
        }
        /// <summary>
        /// Returns the average of all elements 
        /// </summary>
        /// <param name="array">Input 2D array</param>
        /// <returns>double Average</returns>
        public static double GetAverageOf2DArray(int[,] array)
        {
            // throw new Exception("Not Implemented");
            int avrNum = 0;
            int sum = 0;
            for (int i =0;  i < array.GetLength(0); i++)
            {
                for(int j =0; j < array.GetLength(1); j++)
                {
                    sum += array[i,j];
                    avrNum = sum/array.Length;
                }
            }
            return avrNum;
        }
        /// <summary>
        /// Sorts the rows based on the given column index
        /// </summary>
        /// <param name="array">2D array to sort</param>
        /// <param name="columnIndex">The index of the column to sort based on it.</param>
        /// <param name="sortAscending">True sorts ascending, descending otherwise</param>
        /// <returns>Sorted 2D array</returns>
        public static int [,] SortInt2DArray(int[,] array, int columnIndex, bool sortAscending)
        {
            // Hint: use 2 nested for Loops to have 2 indexes. 
            // In the inner for loop, swap the 2 index rows if the second cell is smaller than the first one. Swap all row elements

            //throw new Exception("Not Implemented");

            int rowNum = array.GetLength(0);
            int colNum = array.GetLength(1);


            for(int i =0; i <rowNum -1 ; i++)
            {
                for(int j =i+1; j <colNum; j++)
                {
                    int curVal = array[i,columnIndex];
                    int compareVal = array[j, columnIndex];

                    bool shouldSwap = sortAscending ? curVal > compareVal : curVal < compareVal;

                    if (shouldSwap)
                    {
                        for(int k =0; k < colNum; k++)
                        {
                            int temp = array[i,k];
                            array[i, k] = array[j, k];
                            array[j, k] = temp;
                        }
                    }
                }
            }
            return array;
        }

        public static void StoreInt2DArrayInFile(int[,] data, string FileName)
        {
            //throw new Exception("Not Implemented");
            using (FileStream fs = new FileStream(FileName, FileMode.Create, FileAccess.Write))
            {
                using (StreamWriter sw = new StreamWriter(fs))
                {
                    for (int i =0; i < data.GetLength(0); i++)
                    {
                        for (int j =0; j < data.GetLength(1); j++)
                        {
                            sw.Write(data[i,j]);

                            if (j < data.GetLength(1) - 1)
                            {
                                sw.Write(",");
                            }
                        }
                    if (i <= data.GetLength(0) - 1)
                    {
                            sw.WriteLine();
                    }
                     
                    }                   

                }
               
            }
            
        }

        public static int FindIndexIn2DArray(int[,] data, int value)
        {
            // Hint: The 2D array stored in 1D array, sort it, then you can use Array.BinarySearch()
            // For sorting, you can use your own function, or you can use Arry.Sort()

            //throw new Exception("Not Implemented");

            int total = data.Length;
            int[] newArr = new int[total];
            

            int w = 0;
            for(int i = 0; i <= data.GetUpperBound(0); i++)
            {
                for (int z = 0; z <= data.GetUpperBound(1); z++)
                {
                    newArr[w++] = data[i, z];
                   
                }
                
            }
            Array.Sort(newArr);
            return Array.BinarySearch(newArr,value);

        }
    }
}
