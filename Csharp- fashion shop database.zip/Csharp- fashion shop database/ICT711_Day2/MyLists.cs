﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace ICT711_Day2
{
    public static class MyLists
    {
        public static List<int> createIntList()
        {
           // throw new Exception("Not Implemented");
            List<int> myList = new List<int> { 14, 5, 70, 33 };
            return myList;
        }

        public static List<string> getListWithCapitals(string str)
        {
           // throw new Exception("Not Implemented");
           List<string> strList = str.Split(' ', StringSplitOptions.RemoveEmptyEntries).ToList();
           List<string> result = new List<string>();

           foreach (string s in strList) {

                char[] chars = s.ToCharArray();

                bool hasCap = chars.Any(char.IsUpper);

                if (hasCap) { 
               
                    result.Add(new string(chars));
                
                }                               
            }

           return result;         
        }

    
        public static int findIndexList(List<int> list, int index)
        {
            // Hint: use built-in List methods (FindIndex)
            // throw new Exception("Not Implemented");
            return list.FindIndex(x => x == index);

        }

        public static int getSumOfList(List<int> list)
        {
            // Hint: use built-in List methods
            //throw new Exception("Not Implemented");
            int sum = 0;
            
            for (int i =0; i < list.Count; i++)
            {
                sum += list[i];
            }

            return sum;
            
           
        }

        public static double getAverageOfList(List<int> list)
        {
            // Hint: use built-in List methods
            //throw new Exception("Not Implemented");
            int sum = 0;
            double avr = 0;
            for (int i = 0; i < list.Count; i++)
            {
                sum += list[i];
            }
            avr = (double) sum / list.Count;
            return avr;
        }

        public static List<int> sortIntList(List<int> list)
        {
            // Hint: use built-in List methods
            //throw new Exception("Not Implemented");
            list.Sort();
            return list;
                
        }

        public static List<int> sortDesIntList(List<int> list)
        {
            // Hint: use built-in List methods 
            //throw new Exception("Not Implemented");
            list.Sort((a, b) => b.CompareTo(a));
            return list;
        }
    }

}