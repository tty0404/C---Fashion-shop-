﻿using ICT711_Day2;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.IO;

namespace ICT711_Day2.Tests
{
    [TestClass()]
    public class My2DArraysTests
    {
        [TestMethod()]
        public void MultiplyTest()
        {
            // Instructions
            // In My2DArrays.cs -> Multiply()
            // The method should take arbitrary number of integers
            // Calculate and return the result of multiplying all values
            int expected = 168;
            int actual = My2DArrays.Multiply(1, 4, 7, 6);
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void CalculateRangeSumTest()
        {
            // Instructions
            // In My2DArrays.cs -> CalculateRangeSum()
            // The method should take a range variable
            // Calculate and return the sum of the array values in the given range
            int expected = 5;
            Range r = 2..4;
            int actual = My2DArrays.CalculateRangeSum(r, new[]{ 4, 1, 5, 0, 1});
            Assert.AreEqual(expected, actual);
        }
   
        [TestMethod()]
        public void CreateInt2DArrayTest()
        {
            // Instructions
            // In My2DArrays.cs -> CreateInt2DArray()
            // Create a new Integer 2D Array. Fill-up the array with the values: 
            // 5, 2, 1 
            // 7, 9, 8
            // 3, 4, 6
            // Return the new array

            int[,] expected = { { 5, 2, 1 }, { 7, 9, 8 }, { 3, 4, 6 } };
            int[,] actual = My2DArrays.CreateInt2DArray();
            
            bool equal = true;
            for (int i = 0; i < expected.GetLength(0) && equal; i++)
            {
                for (int j = 0; j < expected.GetLength(1) && equal; j++)
                {
                    equal = expected[i, j] == actual[i,j];
                }
            }
            Assert.IsTrue(equal);
        }

        [TestMethod()]
        public void CreateString2DArrayTest()
        {
            // Instructions
            // Create a 2D jagged string array and store these sales values in it:
            // Monday, 3 sold, 3, 2, 7
            // Tuesday, 2 sold, 9, 2
            // Wednesday, 0 sold
            // Thursday, Holiday
            // Friday, Holiday

            string[] expected = { "Monday", "2 sold", "Holiday" };
            string[][] actual = My2DArrays.CreateString2DArray();

            Assert.AreEqual(expected[0], actual[0][0]);
            Assert.AreEqual(expected[1], actual[1][1]);
            Assert.AreEqual(expected[2], actual[3][1]);
        }

        [TestMethod()]
        public void GetSumOfColumn2DArrayTest()
        {
            // Instructions
            // Calculate the sum of all values for the given column index
            // Return the calculate sum

            int expected = 15;
            int actual = My2DArrays.GetSumOfColumn2DArray(new int[,] { { 5, 2, 1 }, { 7, 9, 8 }, { 3, 4, 6 } }, 2);

            Assert.AreEqual(expected, actual);
        }
        [TestMethod()]
        public void GetSumOfRow2DArrayTest()
        {
            // Instructions
            // Calculate the sum of all values for the given row index
            // Return the calculate sum

            int expected = 13;
            int actual = My2DArrays.GetSumOfRow2DArray(new int[,] { { 5, 2, 1 }, { 7, 9, 8 }, { 3, 4, 6 } }, 2);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void GetAverageOf2DArrayTest()
        {
            // Instructions
            // In MyArrays.cs -> getSumOfArray()
            // Calculate the average of all array values
            // Return the calculate value

            double expected = 5.0d;
            double actual = My2DArrays.GetAverageOf2DArray(new int[,] { { 5, 2, 1 }, { 7, 9, 8 }, { 3, 4, 6 } });
            Assert.AreEqual(expected, actual, 0.0001);
        }
        [TestMethod()]
        public void SortInt2DArrayTest()
        {
            // Instructions
            // sort the array ascending based in the given column index
            // True in the third argument means ascending, false means descending
            // Return the sorted array

            int [,] expected = new int[,] { { 5, 2, 1 }, { 3, 4, 6 }, { 7, 9, 8 } };
            int[,] actual = My2DArrays.SortInt2DArray(new int[,] { { 5, 2, 1 }, { 7, 9, 8 }, { 3, 4, 6 } }, 1, true);

            bool equal = true;
            for (int i = 0; i < expected.GetLength(0) && equal; i++)
            {
                for (int j = 0; j < expected.GetLength(1) && equal; j++)
                {
                    equal = expected[i, j] == actual[i, j];
                }
            }
            Assert.IsTrue(equal);
        }

        [TestMethod()]
        public void StoreInt2DArrayInFileTest()
        {
            // Instructions
            // Create a file with the given name and store the 2D array values as CSV format
            // E.g. of file data: 
            //  5,2,1
            //  7,9,8
            //  3,4,6
            // Return nothing

            string expected = "5,2,1\r\n7,9,8\r\n3,4,6\r\n";
            string FileName = "data.csv";
            My2DArrays.StoreInt2DArrayInFile(new int[,] { { 5, 2, 1 }, { 7, 9, 8 }, { 3, 4, 6 } }, FileName);
            using StreamReader sr = new StreamReader (new FileStream(FileName, FileMode.Open, FileAccess.Read));
            string actual = sr.ReadToEnd();
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void FindIndexIn2DArrayTest()
        {
            // Instructions
            // Find the index of the given value in the given 2D array. 
            // The index should be linear, you need to deal with the 2D array as 1D, and sort it
            // E.g. for the data: 
            //  5, 2, 1
            //  7, 9, 8
            //  3, 4, 6
            // index of 4 is 3, index of 7 is 6

            int expected = 8;
            int actual = My2DArrays.FindIndexIn2DArray(new int[,] { { 5, 2, 1 }, { 7, 9, 8 }, { 3, 4, 6 } }, 9);
            
            Assert.AreEqual(expected, actual);
        }


    }
}