﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ICT711_Day2;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Collections;

namespace ICT711_Day2.Tests
{
    [TestClass()]
    public class MyListsTests
    {
        [TestMethod()]
        public void createIntListTest()
        {
            // Instructions:
            // Create a list and store in it these values:
            // 14, 5, 70, 33
            // Arrange
            int[] expectedValues = { 14, 5, 70, 33 };

            // Act
            List<int> actual = MyLists.createIntList();

            // Assert
            Assert.IsInstanceOfType(actual, typeof(List<int>));
            Assert.AreEqual(expectedValues.Length, actual.Count);
            for (int i = 0; i < expectedValues.Length; i++)
            {
                Assert.AreEqual(expectedValues[i], actual[i]);
            }
        }

        [TestMethod()]
        public void filterListTest()
        {
            // Instructions: in MyLists.getListOfVowel("") 
            // return a list of words from the input string with capital letters
            // Hint: you can split the string first then check the capital

            // Arrange
            List<string> expected = new List<string>{ "Most", "Cats", "lOve", "Mouse"};
            // Act
            List<string> actual = MyLists.getListWithCapitals("Most Cats lOve to hunt Mouse");
            Assert.AreEqual(0, expected.Except(actual).Count() + actual.Except(expected).Count());
        }

        [TestMethod()]
        public void findIndexListTest()
        {
            // Instructions: findIndexList should return the index of the given value in the list
            // Arrange
            List<int> mylist = new List<int>() { 3, 5, 1, 9 };
            int expected = 0;
            // Act
            int actual = MyLists.findIndexList(mylist, 3);
            // Assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void getSumOfListTest()
        {
            // Arrange
            List<int> mylist = new List<int>() { 3, 5, 1, 9 };
            int expected = 18;
            // Act
            int actual = MyLists.getSumOfList(mylist);
            // Assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void getAverageOfListTest()
        {
            // Arrange
            List<int> mylist = new List<int>() { 3, 5, 1, 9 };
            double expected = 4.5;
            // Act
            double actual = MyLists.getAverageOfList(mylist);
            // Assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void sortIntListTest()
        {
            // Arrange
            List<int> mylist = new List<int>() { 3, 5, 1, 9 };
            List<int> expected = new List<int>() { 1, 3, 5, 9 };
            // Act
            List<int> actual = MyLists.sortIntList(mylist);
            // Assert
            Assert.AreEqual(expected[0], actual[0]);
            Assert.AreEqual(expected[1], actual[1]);
            Assert.AreEqual(expected[2], actual[2]);
            Assert.AreEqual(expected[3], actual[3]);
        }

        [TestMethod()]
        public void sortDesIntListTest()
        {
            // Instruction: sortDesIntList returns the list sorted descendingly
            // Arrange
            List<int> mylist = new List<int>() { 3, 5, 1, 9 };
            List<int> expected = new List<int>() { 9, 5, 3, 1 };
            // Act
            List<int> actual = MyLists.sortDesIntList(mylist);
            // Assert
            Assert.AreEqual(expected[0], actual[0]);
            Assert.AreEqual(expected[1], actual[1]);
            Assert.AreEqual(expected[2], actual[2]);
            Assert.AreEqual(expected[3], actual[3]);
        }
    }
}