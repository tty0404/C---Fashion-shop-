﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ICT711_Day3Cont
{
    class Circle : Shape
    {
        public double Radius { get; set; }
        public override double getArea()
        {
            return Math.PI * Math.Pow(Radius, 2);
        }
    }

    class RTriangle : Shape
    {
        public double Base { get; set; }
        public double Height { get; set; }
        public override double getArea()
        {
            return Base *  Height;
        }
    }
}
