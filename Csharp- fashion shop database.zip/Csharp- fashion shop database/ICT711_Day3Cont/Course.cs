﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace ICT711_Day3Cont
{
    
    //definding a new class called Course
    public class Course
    {
        //5 properties
        public DateTime StartDate{ get; set; }
        public DateTime EndtDate{ get; set; }
        public string Subject { get; set; }
        public List<Course> Prerequisites { get; set; }
        public string TeacherName { get; set; }

        //2 method
        public void SetCapacity(int Capacity) {  }
        public bool IsOpen() { return true; }
        
    }
}