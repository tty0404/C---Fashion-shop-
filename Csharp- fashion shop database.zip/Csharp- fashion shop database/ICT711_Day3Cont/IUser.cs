﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ICT711_Day3Cont
{
    public interface IUser
    {
        // Returns the full name
        string getFullName();

    }
}