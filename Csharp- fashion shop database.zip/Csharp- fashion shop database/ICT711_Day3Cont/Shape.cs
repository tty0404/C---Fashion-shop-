﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ICT711_Day3Cont
{
    public abstract class Shape
    {
        /// <summary>
        /// Calculate the area
        /// </summary>
        public abstract double getArea();

        public static int getCircumference()
        {
            return 1;
        }
    }
}