﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ICT711_Day3Cont
{
    public class Student: User
    {
        // 1 field
        private int _courseCount;
        //11 properties
        public string Phone { get; set; }
        public string Email { get; set; }
        public DateTime DOB { get; set; }
        public string GradeLevel { get; set; }
        public string Group { get; set; }
                        
        public Address Address { get ; set; }

        public Course Course1 { get; set; }
        
        public Course Course2 { get; set; }

        public Course Course3 { get; set; }

        public Course Course4 { get; set; }

        public Course Course5 { get; set; }

        // 3 Methods
        public bool registerCourse(string courseID) => true;
        public bool dropCourse(string courseID) => true;
        public bool withdrawCourse(string courseID) => true;
                
    }

    public class Address
    {
        // 4 properties
        public string Street{ get; set; }
        public string City{ get; set; }
        public string Provence{ get; set; }
        public string Country{ get; set; }
    }
}