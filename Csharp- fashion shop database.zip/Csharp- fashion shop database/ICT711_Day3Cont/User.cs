﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ICT711_Day3Cont
{
    public abstract class User: IUser
    {
        public string FName { get; set; }
        public string LName { get; set; }
        
        // Returns the full name
        public string getFullName() // Implementing the interface method
        {
            return FName + " " + LName;
        }

    }
}