﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ICT711_Day3Cont
{

    public static class XOcontrollerSolution
    {
        static XOcontrollerSolution()
        {
            Init();
        }
        /// <summary>
        /// Stores the next player (X or O)
        /// </summary>
        public static string NextPlayer { get; set; }
        /// <summary>
        /// Stores the game board data
        /// </summary>
        private static string[,] gameBoard;
        /// <summary>
        /// Stores a list of all game moves. Used for Undo function
        /// </summary>
        private static Stack<int[]> moveList = new Stack<int[]>();

        private static string _winner = "";
        public static string Winner { get { return _winner; } }

        /// <summary>
        /// Reset the game
        /// </summary>
        public static void Init()
        {
            NextPlayer = "X";
            gameBoard = new string[,] {
                { "_", "_", "_" },
                { "_", "_", "_" },
                { "_", "_", "_" } };
            moveList.Clear();
            _winner = "";
        }

        /// <summary>
        /// Records a new play
        /// </summary>
        /// <param name="position">Next move position</param>
        public static void Play(int[] position)
        {
            // Check if the game ended or position is used
            if (Winner.Length > 0 || getPosition(position) != "_")
                return;
            gameBoard[position[0], position[1]] = NextPlayer;
            // Add the current move to the list
            moveList.Push(position);
            // check winner
            checkWinner();
            // To-Do: advance the NextPlayer.
            NextPlayer = NextPlayer == "X" ? "O" : "X";
        }
        /// <summary>
        /// Undo the last move
        /// </summary>
        public static void Undo()
        {
            // To-Do
            // Make sure first that there are moves in the moveList to be undo
            if (moveList.Count == 0) return;
            // set the _winner to empty
            _winner = "";
            // remove the last move from moveList
             int [] lastMovePositio = moveList.Pop();
            // set the NextPlayer to the removed position value (read the value from gameBoard)
            NextPlayer = getPosition(lastMovePositio);
            // set the gameBoard position to "_"
            gameBoard[lastMovePositio[0], lastMovePositio[1]] = "_";
            return;
        }

        /// <summary>
        /// Gets the value for the given position
        /// </summary>
        /// <param name="position">Target Position</param>
        /// <returns>The current position value</returns>
        static public string getPosition(int[] position)
        {
            return gameBoard[position[0], position[1]];
        }

        /// <summary>
        /// Checks if there is current winner or if the game is over
        /// </summary>
        private static void checkWinner()
        {
            // To-Do
            // Check winner by checking if any column or row or diagonal has 3 equal values that are either X or O
            // if there is a winner, set _winner to either "X Winner!" or "O Winner!"
            // if number of moves equals 9 and no winner, set _winner = "Game Over!!!"
            // Hint: you can use the below Lambada expressions if you want
            Func<string[], bool> isWinner = 
                (x) => x[0] == x[1] && x[0] == x[2] && x[0] != "_";
            Func<int, string[]> getRow =
                (i) => new[] { gameBoard[i, 0], gameBoard[i, 1], gameBoard[i, 2] };
            Func<int, string[]> getCol =
                (i) => new[] { gameBoard[0, i], gameBoard[1, i], gameBoard[2, i] };
            Func<int, string[]> getDiag =
                (i) => new[] { gameBoard[1-i, 0], gameBoard[1, 1], gameBoard[1+i, 2] };

            for (int i = 0; i < 3; i++) {
                _winner = isWinner(getRow(i)) ? gameBoard[i, i] + " Winner!" : "";
                _winner += isWinner(getCol(i)) ? gameBoard[i, i] + " Winner!" : "";
                if(_winner.Length > 1) return;
            }
            _winner = isWinner(getDiag(1)) ? gameBoard[1, 1] + " Winner!" : "";
            _winner += isWinner(getDiag(-1)) ? gameBoard[1, 1] + " Winner!" : "";

            if (moveList.Count == 9 && _winner == "") _winner = "Game Over!!!";
            return;
        }

        public static int[] parseIndex(string name)
        {
            return (from value in name.Replace("label_", "").Split('_')
                    select Int32.Parse(value)).ToArray();
        }
    }
}
