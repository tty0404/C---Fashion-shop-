﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ICT711_Day3Cont;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


// This test works on XOcontroller.cs. Please follow the To-Do instructions there.
namespace ICT711_Day3Cont.Tests
{
    [TestClass()]
    public class XOcontrollerTests
    {
        [TestMethod()]
        public void PlayTest()
        {
            // Check correct moves
            // in Play: Advance the NextPlayer at the end of the function to the next play
            XOcontroller.Init();
            XOcontroller.Play(new[] { 0, 0 });  // X
            XOcontroller.Play(new[] { 0, 1 });  // O
            XOcontroller.Play(new[] { 1, 0 });  // X
            XOcontroller.Play(new[] { 1, 0 });  // X
            XOcontroller.Play(new[] { 1, 1 });  // O
            XOcontroller.Play(new[] { 2, 0 });  // X
            Assert.AreEqual("X", XOcontroller.getPosition(new[] { 0, 0 }));
            Assert.AreEqual("O", XOcontroller.getPosition(new[] { 0, 1 }));
            Assert.AreEqual("X", XOcontroller.getPosition(new[] { 1, 0 }));
            Assert.AreEqual("X", XOcontroller.getPosition(new[] { 2, 0 }));            
        }

        [TestMethod()]
        public void CheckWinnerTest()
        {
            // Check correct play
            // The last move should not work as the game will end before it
            // Build the checkWinner() method
            XOcontroller.Init();
            XOcontroller.Play(new[] { 0, 0 });  // X
            XOcontroller.Play(new[] { 0, 1 });  // O
            XOcontroller.Play(new[] { 1, 0 });  // X
            XOcontroller.Play(new[] { 1, 0 });  // O
            XOcontroller.Play(new[] { 1, 1 });  // X
            XOcontroller.Play(new[] { 2, 0 });  // O
            XOcontroller.Play(new[] { 2, 1 });  // X -> _
            Assert.AreEqual("X", XOcontroller.getPosition(new[] { 0, 0 }));
            Assert.AreEqual("O", XOcontroller.getPosition(new[] { 0, 1 }));
            Assert.AreEqual("_", XOcontroller.getPosition(new[] { 2, 1 }));
        }

        [TestMethod()]
        public void CheckWinner2Test()
        {
            // Check correct positions and X winner
            XOcontroller.Init();
            XOcontroller.Play(new[] { 0, 0 });  // X
            XOcontroller.Play(new[] { 0, 1 });  // O
            XOcontroller.Play(new[] { 1, 0 });  // X
            XOcontroller.Play(new[] { 1, 0 });  // O
            XOcontroller.Play(new[] { 1, 1 });  // X
            XOcontroller.Play(new[] { 2, 0 });  // O
            Assert.AreEqual("X", XOcontroller.getPosition(new[] { 0, 0 }));
            Assert.AreEqual("O", XOcontroller.getPosition(new[] { 0, 1 }));
            Assert.AreEqual("X Winner!", XOcontroller.Winner);
        }

        [TestMethod()]
        public void CheckWinner3Test()
        {
            // Check diagonal winner
            XOcontroller.Init();
            XOcontroller.Play(new[] { 0, 1 });  // X
            XOcontroller.Play(new[] { 0, 2 });  // O
            XOcontroller.Play(new[] { 1, 0 });  // X
            XOcontroller.Play(new[] { 1, 1 });  // O
            XOcontroller.Play(new[] { 2, 1 });  // X
            XOcontroller.Play(new[] { 2, 0 });  // O
            Assert.AreEqual("O Winner!", XOcontroller.Winner);
        }

        [TestMethod()]
        public void CheckGameOverTest()
        {
            // Check case of game over
            XOcontroller.Init();
            XOcontroller.Play(new[] { 0, 0 });  // X    X   O   X
            XOcontroller.Play(new[] { 0, 1 });  // O    O   X   X
            XOcontroller.Play(new[] { 0, 2 });  // X    O   X   O
            XOcontroller.Play(new[] { 1, 0 });  // O
            XOcontroller.Play(new[] { 1, 1 });  // X
            XOcontroller.Play(new[] { 2, 2 });  // O
            XOcontroller.Play(new[] { 2, 1 });  // X
            XOcontroller.Play(new[] { 2, 0 });  // O
            XOcontroller.Play(new[] { 1, 2 });  // X
            Assert.AreEqual("Game Over!!!", XOcontroller.Winner);
        }

        [TestMethod()]
        public void CheckUndoTest()
        {
            // Check if undo works correct
            XOcontroller.Init();
            XOcontroller.Play(new[] { 0, 0 });  // X    X   O   X
            XOcontroller.Play(new[] { 0, 1 });  // O    O   
            XOcontroller.Play(new[] { 0, 2 });  // X    
            XOcontroller.Play(new[] { 1, 0 });  // O
            XOcontroller.Undo();
            XOcontroller.Undo();
            XOcontroller.Undo();
            XOcontroller.Play(new[] { 2, 0 });  // O
            Assert.AreEqual("_", XOcontroller.getPosition(new[] { 1, 0 }));
            Assert.AreEqual("_", XOcontroller.getPosition(new[] { 0, 1 }));
            Assert.AreEqual("O", XOcontroller.getPosition(new[] { 2, 0 }));
        }

        [TestMethod()]
        public void CheckUndo2Test()
        {
            // Checks O winner and the winner is empty after Undo
            XOcontroller.Init();
            XOcontroller.Play(new[] { 0, 0 });  // X    X       X
            XOcontroller.Play(new[] { 1, 0 });  // O    O   O   O
            XOcontroller.Play(new[] { 0, 2 });  // X    X
            XOcontroller.Play(new[] { 1, 1 });  // O
            XOcontroller.Play(new[] { 2, 0 });  // X
            XOcontroller.Play(new[] { 1, 2 });  // O
            Assert.AreEqual("O Winner!", XOcontroller.Winner);
            XOcontroller.Undo();
            Assert.AreEqual("", XOcontroller.Winner);
        }
    }
}