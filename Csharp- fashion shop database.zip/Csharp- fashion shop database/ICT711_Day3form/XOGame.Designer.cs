﻿namespace ICT711_Day3form
{
    partial class XOGame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.playerOlabel = new System.Windows.Forms.Label();
            this.playerXlabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label_2_2 = new System.Windows.Forms.Label();
            this.label_2_1 = new System.Windows.Forms.Label();
            this.label_2_0 = new System.Windows.Forms.Label();
            this.label_1_2 = new System.Windows.Forms.Label();
            this.label_1_1 = new System.Windows.Forms.Label();
            this.label_1_0 = new System.Windows.Forms.Label();
            this.label_0_2 = new System.Windows.Forms.Label();
            this.label_0_1 = new System.Windows.Forms.Label();
            this.label_0_0 = new System.Windows.Forms.Label();
            this.restartButton = new System.Windows.Forms.Button();
            this.undoButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.undoButton);
            this.splitContainer1.Panel1.Controls.Add(this.restartButton);
            this.splitContainer1.Panel1.Controls.Add(this.playerOlabel);
            this.splitContainer1.Panel1.Controls.Add(this.playerXlabel);
            this.splitContainer1.Panel1.Controls.Add(this.label1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.tableLayoutPanel1);
            this.splitContainer1.Size = new System.Drawing.Size(489, 440);
            this.splitContainer1.SplitterDistance = 58;
            this.splitContainer1.TabIndex = 0;
            // 
            // playerOlabel
            // 
            this.playerOlabel.AutoSize = true;
            this.playerOlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.playerOlabel.ForeColor = System.Drawing.Color.Magenta;
            this.playerOlabel.Location = new System.Drawing.Point(116, 21);
            this.playerOlabel.Name = "playerOlabel";
            this.playerOlabel.Size = new System.Drawing.Size(29, 26);
            this.playerOlabel.TabIndex = 0;
            this.playerOlabel.Text = "O";
            // 
            // playerXlabel
            // 
            this.playerXlabel.AutoSize = true;
            this.playerXlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.playerXlabel.ForeColor = System.Drawing.Color.Red;
            this.playerXlabel.Location = new System.Drawing.Point(103, 21);
            this.playerXlabel.Name = "playerXlabel";
            this.playerXlabel.Size = new System.Drawing.Size(27, 26);
            this.playerXlabel.TabIndex = 0;
            this.playerXlabel.Text = "X";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkRed;
            this.label1.Location = new System.Drawing.Point(12, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Next Player";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 34F));
            this.tableLayoutPanel1.Controls.Add(this.label_2_2, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.label_2_1, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.label_2_0, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label_1_2, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.label_1_1, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.label_1_0, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label_0_2, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.label_0_1, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label_0_0, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(10);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.Padding = new System.Windows.Forms.Padding(10);
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 34F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(489, 378);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // label_2_2
            // 
            this.label_2_2.AutoSize = true;
            this.label_2_2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label_2_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_2_2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label_2_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_2_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_2_2.ForeColor = System.Drawing.Color.Red;
            this.label_2_2.Location = new System.Drawing.Point(321, 249);
            this.label_2_2.Margin = new System.Windows.Forms.Padding(3);
            this.label_2_2.Name = "label_2_2";
            this.label_2_2.Size = new System.Drawing.Size(155, 116);
            this.label_2_2.TabIndex = 8;
            this.label_2_2.Tag = "2,2";
            this.label_2_2.Text = "_";
            this.label_2_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label_2_2.Click += new System.EventHandler(this.label_x_y_Click);
            this.label_2_2.Paint += new System.Windows.Forms.PaintEventHandler(this.label_x_y_Paint);
            // 
            // label_2_1
            // 
            this.label_2_1.AutoSize = true;
            this.label_2_1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label_2_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_2_1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label_2_1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_2_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_2_1.ForeColor = System.Drawing.Color.Red;
            this.label_2_1.Location = new System.Drawing.Point(167, 249);
            this.label_2_1.Margin = new System.Windows.Forms.Padding(3);
            this.label_2_1.Name = "label_2_1";
            this.label_2_1.Size = new System.Drawing.Size(148, 116);
            this.label_2_1.TabIndex = 7;
            this.label_2_1.Tag = "2,1";
            this.label_2_1.Text = "_";
            this.label_2_1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label_2_1.Click += new System.EventHandler(this.label_x_y_Click);
            this.label_2_1.Paint += new System.Windows.Forms.PaintEventHandler(this.label_x_y_Paint);
            // 
            // label_2_0
            // 
            this.label_2_0.AutoSize = true;
            this.label_2_0.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label_2_0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_2_0.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label_2_0.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_2_0.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_2_0.ForeColor = System.Drawing.Color.Red;
            this.label_2_0.Location = new System.Drawing.Point(13, 249);
            this.label_2_0.Margin = new System.Windows.Forms.Padding(3);
            this.label_2_0.Name = "label_2_0";
            this.label_2_0.Size = new System.Drawing.Size(148, 116);
            this.label_2_0.TabIndex = 6;
            this.label_2_0.Tag = "2,0";
            this.label_2_0.Text = "_";
            this.label_2_0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label_2_0.Click += new System.EventHandler(this.label_x_y_Click);
            this.label_2_0.Paint += new System.Windows.Forms.PaintEventHandler(this.label_x_y_Paint);
            // 
            // label_1_2
            // 
            this.label_1_2.AutoSize = true;
            this.label_1_2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label_1_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_1_2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label_1_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_1_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_1_2.ForeColor = System.Drawing.Color.Red;
            this.label_1_2.Location = new System.Drawing.Point(321, 131);
            this.label_1_2.Margin = new System.Windows.Forms.Padding(3);
            this.label_1_2.Name = "label_1_2";
            this.label_1_2.Size = new System.Drawing.Size(155, 112);
            this.label_1_2.TabIndex = 5;
            this.label_1_2.Tag = "[1,2]";
            this.label_1_2.Text = "_";
            this.label_1_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label_1_2.Click += new System.EventHandler(this.label_x_y_Click);
            this.label_1_2.Paint += new System.Windows.Forms.PaintEventHandler(this.label_x_y_Paint);
            // 
            // label_1_1
            // 
            this.label_1_1.AutoSize = true;
            this.label_1_1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label_1_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_1_1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label_1_1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_1_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_1_1.ForeColor = System.Drawing.Color.Red;
            this.label_1_1.Location = new System.Drawing.Point(167, 131);
            this.label_1_1.Margin = new System.Windows.Forms.Padding(3);
            this.label_1_1.Name = "label_1_1";
            this.label_1_1.Size = new System.Drawing.Size(148, 112);
            this.label_1_1.TabIndex = 4;
            this.label_1_1.Tag = "[1,1]";
            this.label_1_1.Text = "_";
            this.label_1_1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label_1_1.Click += new System.EventHandler(this.label_x_y_Click);
            this.label_1_1.Paint += new System.Windows.Forms.PaintEventHandler(this.label_x_y_Paint);
            // 
            // label_1_0
            // 
            this.label_1_0.AutoSize = true;
            this.label_1_0.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label_1_0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_1_0.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label_1_0.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_1_0.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_1_0.ForeColor = System.Drawing.Color.Red;
            this.label_1_0.Location = new System.Drawing.Point(13, 131);
            this.label_1_0.Margin = new System.Windows.Forms.Padding(3);
            this.label_1_0.Name = "label_1_0";
            this.label_1_0.Size = new System.Drawing.Size(148, 112);
            this.label_1_0.TabIndex = 3;
            this.label_1_0.Tag = "[1,0]";
            this.label_1_0.Text = "_";
            this.label_1_0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label_1_0.Click += new System.EventHandler(this.label_x_y_Click);
            this.label_1_0.Paint += new System.Windows.Forms.PaintEventHandler(this.label_x_y_Paint);
            // 
            // label_0_2
            // 
            this.label_0_2.AutoSize = true;
            this.label_0_2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label_0_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_0_2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label_0_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_0_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_0_2.ForeColor = System.Drawing.Color.Red;
            this.label_0_2.Location = new System.Drawing.Point(321, 13);
            this.label_0_2.Margin = new System.Windows.Forms.Padding(3);
            this.label_0_2.Name = "label_0_2";
            this.label_0_2.Size = new System.Drawing.Size(155, 112);
            this.label_0_2.TabIndex = 2;
            this.label_0_2.Tag = "0,2";
            this.label_0_2.Text = "_";
            this.label_0_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label_0_2.Click += new System.EventHandler(this.label_x_y_Click);
            this.label_0_2.Paint += new System.Windows.Forms.PaintEventHandler(this.label_x_y_Paint);
            // 
            // label_0_1
            // 
            this.label_0_1.AutoSize = true;
            this.label_0_1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label_0_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_0_1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label_0_1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_0_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_0_1.ForeColor = System.Drawing.Color.Red;
            this.label_0_1.Location = new System.Drawing.Point(167, 13);
            this.label_0_1.Margin = new System.Windows.Forms.Padding(3);
            this.label_0_1.Name = "label_0_1";
            this.label_0_1.Size = new System.Drawing.Size(148, 112);
            this.label_0_1.TabIndex = 1;
            this.label_0_1.Tag = "0,1";
            this.label_0_1.Text = "_";
            this.label_0_1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label_0_1.Click += new System.EventHandler(this.label_x_y_Click);
            this.label_0_1.Paint += new System.Windows.Forms.PaintEventHandler(this.label_x_y_Paint);
            // 
            // label_0_0
            // 
            this.label_0_0.AutoSize = true;
            this.label_0_0.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label_0_0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_0_0.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label_0_0.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_0_0.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_0_0.ForeColor = System.Drawing.Color.Red;
            this.label_0_0.Location = new System.Drawing.Point(13, 13);
            this.label_0_0.Margin = new System.Windows.Forms.Padding(3);
            this.label_0_0.Name = "label_0_0";
            this.label_0_0.Size = new System.Drawing.Size(148, 112);
            this.label_0_0.TabIndex = 0;
            this.label_0_0.Tag = "{0,0}";
            this.label_0_0.Text = "_";
            this.label_0_0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label_0_0.Click += new System.EventHandler(this.label_x_y_Click);
            this.label_0_0.Paint += new System.Windows.Forms.PaintEventHandler(this.label_x_y_Paint);
            // 
            // restartButton
            // 
            this.restartButton.Location = new System.Drawing.Point(401, 17);
            this.restartButton.Name = "restartButton";
            this.restartButton.Size = new System.Drawing.Size(75, 23);
            this.restartButton.TabIndex = 1;
            this.restartButton.Text = "&Restart";
            this.restartButton.UseVisualStyleBackColor = true;
            this.restartButton.Click += new System.EventHandler(this.restartButton_Click);
            // 
            // undoButton
            // 
            this.undoButton.Location = new System.Drawing.Point(321, 17);
            this.undoButton.Name = "undoButton";
            this.undoButton.Size = new System.Drawing.Size(54, 23);
            this.undoButton.TabIndex = 2;
            this.undoButton.Text = "&Undo";
            this.undoButton.UseVisualStyleBackColor = true;
            this.undoButton.Click += new System.EventHandler(this.undoButton_Click);
            // 
            // XOGame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(489, 440);
            this.Controls.Add(this.splitContainer1);
            this.Name = "XOGame";
            this.Text = "XO Game";
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Label playerOlabel;
        private System.Windows.Forms.Label playerXlabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label_2_2;
        private System.Windows.Forms.Label label_2_1;
        private System.Windows.Forms.Label label_2_0;
        private System.Windows.Forms.Label label_1_2;
        private System.Windows.Forms.Label label_1_1;
        private System.Windows.Forms.Label label_1_0;
        private System.Windows.Forms.Label label_0_2;
        private System.Windows.Forms.Label label_0_1;
        private System.Windows.Forms.Label label_0_0;
        private System.Windows.Forms.Button restartButton;
        private System.Windows.Forms.Button undoButton;
    }
}

