﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ICT711_Day3Cont;

namespace ICT711_Day3form
{
    public partial class XOGame : Form
    {
        
        public XOGame()
        {
            InitializeComponent();
            // Initialize the next player
            XOcontroller.Init();
            setNextPlayer();
        }
        
        private void label_x_y_Click(object sender, EventArgs e)
        {
            Label Lbl = (Label)sender;
            int[] position = XOcontroller.parseIndex(Lbl.Name);
            XOcontroller.Play(position);
            Lbl.Invalidate();   // To draw the label with the new value
            setNextPlayer();
        }

        private void setNextPlayer()
        {
            if (XOcontroller.Winner.Length > 0)
            {   // Game end
                playerXlabel.Text = XOcontroller.Winner;
                playerXlabel.Visible = true;
                playerOlabel.Visible = false;
                return;
            }
            if(XOcontroller.NextPlayer == "X")
            {
                playerXlabel.Text = XOcontroller.NextPlayer;
                playerXlabel.Visible = true;
                playerOlabel.Visible = false;                
            }
            if (XOcontroller.NextPlayer == "O")
            {
                playerXlabel.Visible = false;
                playerOlabel.Visible = true;                
            }
        }

        private void restartButton_Click(object sender, EventArgs e)
        {
            XOcontroller.Init();
            setNextPlayer();
            this.Invalidate(true);
        }

        private void label_x_y_Paint(object sender, PaintEventArgs e)
        {
            // Fills the View grid with values from the Gameboard data
            Label Lbl = (Label)sender;
            // Read the current index from the label name
            int[] position = XOcontroller.parseIndex(Lbl.Name);
            string txt = XOcontroller.getPosition(position);
            if (Lbl.Text == txt) return;
            Lbl.Text = txt;
            // Set the font color 
            Lbl.ForeColor = Color.Red;
            if (Lbl.Text == "O")
                Lbl.ForeColor = Color.Magenta;
        }

        private void undoButton_Click(object sender, EventArgs e)
        {
            // Undo last move
            XOcontroller.Undo();
            setNextPlayer();
            this.Invalidate(true);
        }
    }
}
