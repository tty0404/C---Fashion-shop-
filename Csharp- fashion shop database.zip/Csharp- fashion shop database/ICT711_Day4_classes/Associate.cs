﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ICT711_Day4_classes
{
    internal class Associate : Person, IAssociate
    {
        public int AssociateId { get ; set; }
        public string Department { get; set; }
        public string JobDescription { get; set; }
        public int ManagerId { get; set; }

        public string GetManager()
        {
            throw new NotImplementedException();
        }
    }
}
