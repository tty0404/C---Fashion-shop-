﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ICT711_Day4_classes
{
    public class Customer : Person, ICustomer
    {
        public int CustomerId { get; set; }
        public int MainAssociate { get; set; }
        public DateTime RegisteredOn { get; set; }

        public string GetAssociate()
        {
            throw new NotImplementedException();
        }

        public List<IProduct> GetPurchases()
        {
            throw new NotImplementedException();
        }
    }
}