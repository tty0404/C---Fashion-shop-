﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ICT711_Day4_classes
{
    public interface IAssociate
    {
        int AssociateId { get; set; }
        /// <summary>
        /// The department
        /// </summary>
        string Department { get; set; }
        /// <summary>
        /// The job description
        /// </summary>
        string JobDescription { get; set; }
        /// <summary>
        /// The manager Id
        /// </summary>
        int ManagerId { get; set; }
        /// <summary>
        /// Gets the manager full name
        /// </summary>
        string GetManager();
    }
}