﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ICT711_Day4_classes
{
    public interface ICustomer
    {
        int CustomerId { get; set; }
        /// <summary>
        /// The Id of the main associate working with this customer
        /// </summary>
        int MainAssociate { get; set; }
        /// <summary>
        /// When was the customer first registered. Auto-populate to the current date-time
        /// </summary>
        System.DateTime RegisteredOn { get; set; }
        /// <summary>
        /// Returns a list of all purchased products
        /// </summary>
        List<IProduct> GetPurchases();
        /// <summary>
        /// Gets the full name of the main associate
        /// </summary>
        string GetAssociate();
    }
}