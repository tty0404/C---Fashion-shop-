﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ICT711_Day4_classes
{
    public interface IInventory
    {
        /// <summary>
        /// List of all available products
        /// </summary>
        List<IProduct> Products { get; set; }

        /// <param name="product">The product to add</param>
        void AddProduct(IProduct product);
        /// <summary>
        /// Removes product from inventory
        /// </summary>
        void RemoveProduct(IProduct product);
        /// <summary>
        /// Loads the inventory data from file
        /// </summary>
        void LoadInventory();
        /// <summary>
        /// Saves the inventory data to the file
        /// </summary>
        void SaveInventory();
    }
}