﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ICT711_Day4_classes
{
    public interface IProduct
    {

        int ProductId { get; set; }
        string ProductName { get; set; }
        string Description { get; set; }
        decimal Price { get; set; }
        /// <summary>
        /// Available Quantity
        /// </summary>
        int Quantity { get; set; }
        /// <summary>
        /// returns the sub total
        /// </summary>
        decimal GetSubTotal();
    }
}