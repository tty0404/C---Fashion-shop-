﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ICT711_Day4_classes
{
    public interface ISale
    {
        int Id { get; set; }
        /// <summary>
        /// Sale Date
        /// </summary>
        System.DateTime Date { get; set; }
        int Total { get; set; }
        /// <summary>
        /// Id of the customer
        /// </summary>
        int CustomerId { get; set; }
        /// <summary>
        /// Id of the associate
        /// </summary>
        int AssociateId { get; set; }
        /// <summary>
        /// List of all purchased products
        /// </summary>
        List<IProduct> ProductsList { get; set; }

        /// <summary>
        /// Adds a product to the sale
        /// </summary>
        /// <param name="product">Object of the product to add to the sale</param>
        void AddProduct(IProduct product);
        /// <summary>
        /// Gets the sale total
        /// </summary>
        decimal GetTotal();
    }
}