﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ICT711_Day4_classes
{
    internal class Inventory : IInventory
    {
        public List<IProduct> Products { get; set; }

        public void AddProduct(IProduct product)
        {
            throw new NotImplementedException();
        }

        public void LoadInventory()
        {
            throw new NotImplementedException();
        }

        public void RemoveProduct(IProduct product)
        {
            throw new NotImplementedException();
        }

        public void SaveInventory()
        {
            throw new NotImplementedException();
        }
    }
}
