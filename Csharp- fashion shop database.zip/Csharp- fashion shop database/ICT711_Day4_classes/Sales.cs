﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ICT711_Day4_classes
{
    internal class Sales : ISale
    {
        public int Id { get; set; }
        public DateTime Date { get; set; }
        public int Total { get; set; }
        public int CustomerId { get; set; }
        public int AssociateId { get; set; }
        public List<IProduct> ProductsList { get; set; }

        public void AddProduct(IProduct product)
        {
            throw new NotImplementedException();
        }

        public decimal GetTotal()
        {
            throw new NotImplementedException();
        }
    }
}
