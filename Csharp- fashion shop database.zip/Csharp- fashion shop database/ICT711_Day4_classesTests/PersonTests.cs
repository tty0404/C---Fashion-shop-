﻿using ICT711_Day4_classesTests;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;

namespace ICT711_Day4_classes.Tests
{
    [TestClass()]
    public class PersonTests
    {
        [TestMethod()]
        public void FNameTest()
        {
            // Add FName property to the Person Class
            Person p = new Person();
            
            Assert.IsTrue(p.HasProperty("FName"));
        }
        [TestMethod()]
        public void LNameTest()
        {
            // Add LName property to the Person Class
            Person p = new Person();

            Assert.IsTrue(p.HasProperty("LName"));
        }
        [TestMethod()]
        public void GetFullNameTest()
        {
            // Add GetFullName method to the Person Class
            Person p = new Person();

            Assert.IsTrue(p.HasMethod("GetFullName"));
        }

        [TestMethod()]
        public void GetFullNameTest2()
        {
            // Full name should return the full user name i.e.: "FName LName"
            IPerson p = (IPerson)new Person();
            p.FName = "John";
            p.LName = "Doe";
            string actrual = p.GetFullName();
            string expected = "John Doe";
            Assert.AreEqual(expected, actrual);
        }
    }
}