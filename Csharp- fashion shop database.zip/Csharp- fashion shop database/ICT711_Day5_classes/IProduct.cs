﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ICT711_Day5_classes
{
    public interface IProduct
    {

        int ProductId { get; set; }
        string ProductName { get; set; }
        string Description { get; set; }
        decimal Price { get; set; }
        /// <summary>
        /// Available quantity
        /// </summary>
        int Quantity { get; set; }
        /// <summary>
        /// Returns the sub total. Should be defined as virtual
        /// </summary>
        decimal GetSubTotal();
        /// <summary>
        /// Adds the quantity of the given product to the current product 
        /// Checks first to make sure the Product IDs are the same
        /// </summary>
        /// <param name="product1"></param>
        /// <returns>Returns current product with updated quantity. Should be defined as virtual</returns>
        Product Add(Product product1);
        /// <summary>
        /// Deduct the quantity of the given product from the current product 
        /// Checks first to make sure the Product IDs are the same, and that there is enough quantity
        /// </summary>
        /// <param name="product1">Product to deduct its quantity</param>
        /// <returns>Returns current product with updated quantity. Should be defined as virtual</returns>
        Product Remove(Product product1);
    }
}