﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;

namespace ICT711_Day5_classes
{
    public interface IStore
    {
        public string StoreName { get; set; }

        public string Address { get; set; }

        /// <summary>
        /// List of all customers
        /// </summary>
        [JsonIgnore]    // Don't store this data inside the store file. Will be stored in a separate file
        public List<ICustomer> Customers { get; set; }

        /// <summary>
        /// List of all store associates
        /// </summary>
        [JsonIgnore]    // Don't store this data inside the store file. Will be stored in a separate file
        public List<IAssociate> Associates { get; set; }

        /// <summary>
        /// Store inventory
        /// </summary>
        [JsonIgnore]    // Don't store this data inside the store file. Will be stored in a separate file
        public Inventory Inventory { get; set; }
        /// <summary>
        /// List of all sales
        /// </summary>
        [JsonIgnore]    // Don't store this data inside the store file. Will be stored in a separate file
        public List<ISale> Sales { get; set; }
        /// <summary>
        /// The file name to store the associates list. 
        /// </summary>
        static string AssociatesFileName { get; set; } = "associates.json";
        /// <summary>
        /// The file name to store the customers list. 
        /// </summary>
        static string CustomersFileName { get; set; } = "customers.json";
        /// <summary>
        /// The file name to store the inventory list. 
        /// </summary>
        static string InventoryFileName { get; set; } = "inventory.json";
        /// <summary>
        /// The file name to store the sales list. 
        /// </summary>
        static string SalesFileName { get; set; } = "sales.json";

        /// <summary>
        /// Loads all customers
        /// </summary>
        public void LoadCustomers();

        /// <summary>
        /// Saves all customers
        /// </summary>
        public void SaveCustomers();

        /// <summary>
        /// Loads all sales
        /// </summary>
        public void LoadSales();

        /// <summary>
        /// Saves all sales
        /// </summary>
        public void SaveSales();

        /// <summary>
        /// Loads all associates
        /// </summary>
        public void LoadAssociates();

        /// <summary>
        /// Saves all associated
        /// </summary>
        public void SaveAssociates();
        /// <summary>
        /// Loads inventory data
        /// </summary>
        void LoadInventory();
        /// <summary>
        /// Saves Inventory data
        /// </summary>
        void SaveInventory();
        /// <summary>
        /// Saves Store Information (without the data lists such as Customer, Associates, etc.)
        /// </summary>
        void SaveStoreInfo(string StoreDataFileName = null);
        /// <summary>
        /// Create a new store object from the serialized Json store file
        /// </summary>
        /// <returns>A new store object deserialized from the JSON file</returns>
        static abstract Store CreateStore();   // Factory method
    }
}