﻿using Microsoft.VisualBasic.CompilerServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ICT711_Day5_classes
{
    public class Inventory : IInventory
    {

        private List<Product> products = new List<Product>();
        public List<IProduct> this[string search]
        {
            get
            {
                return products
                    .Where(p => p.ProductName.ToLower().Contains(search.ToLowerInvariant()))
                    .Select(p => (IProduct)p)
                    .ToList();

            }

        }


        public IProduct this[int productId]
        {
            get { return products.FirstOrDefault(p => p.ProductId == productId); }
        }

        public List<Product> Products { get { return products; } set { products = value; } }



        public Inventory() { }


        public bool AddProduct(Product product)
        {
            //throw new NotImplementedException();
            if (product != null)
            {
                Product existingProduct = products.FirstOrDefault(p => p.ProductId == product.ProductId);
                if (existingProduct != null)
                {
                    existingProduct.Quantity += product.Quantity;
                }

                else
                { products.Add(product); }
                return true;
            }
            return false;

        }


        public static Inventory operator +(Inventory inventory, Product product)
        {
            inventory.AddProduct(product);
            return inventory;
        }

        //public static Inventory operator +(Product product, int q)
        //{
        //    product.Quantity += q;
        //    return product.Quantity;
        //}

        public bool RemoveProduct(Product RemProduct)
        {

            if (RemProduct == null)
            {
                throw new Exception("Product cannot be null.");
            }               
  
            List<int> id = new List<int>();
            foreach (Product product in Products)
            {
                id.Add(product.ProductId);
            }

            foreach(Product product in Products)
            {
                if (!id.Contains(RemProduct.ProductId))
                {
                        throw new Exception("Product is not in inventory.");
                }

                    if(product.ProductId == RemProduct.ProductId)
                    {
                        if(product.Quantity < RemProduct.Quantity)
                        {
                            throw new ArgumentOutOfRangeException("Quantity", "There is not enough quantity.");
                        }

                        if(product is ProductGarment && RemProduct is ProductGarment)
                        {
                            ((ProductGarment)product).Remove(RemProduct);
                        }
                        
                        else
                        {
                        product.Quantity -= RemProduct.Quantity;
                        }
                    }

                    
            }

            return Products.Remove(RemProduct);
 
        }

            
        

        public static Inventory operator -(Inventory inventory, Product product)
        {
            inventory.RemoveProduct(product);
            return inventory;
        }





    }


       
}