﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ICT711_Day5_classes
{
    public class Product : IProduct
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        public int Quantity { get; set; }

        public Product()
        {
            // Initialize the ProductId with a random value
            this.ProductId = new Random().Next();
        }

        // Parametrized constructor
        public Product(int productId, string productName, string description, 
            decimal price, int quantity)
        {
            // Initialize the local variables using the given parameters     
            this.ProductId = productId;
            this.ProductName = productName;
            this.Description = description;
            this.Price = price;
            this.Quantity = quantity;
        }

        // Cloning constructor
        public Product(Product product)
        {
            // Initialize the local properties using the given Object's properties
            //throw new NotImplementedException();
            this.ProductId = product.ProductId;
            this.ProductName = product.ProductName;
            this.Description = product.Description;
            this.Price = product.Price; 
            this.Quantity = product.Quantity;
    

    }

        // Parametrized constructor
        public Product(string productName, string description, decimal price, int quantity)
        {
            // Initialize the ProductId with a random value
            // Initialize the local variables using the given parameters
           // throw new NotImplementedException();
           this.ProductName= productName;
           this.Description = description;
           this.Price = price;
           this.Quantity = quantity;
        }

        /// <summary>
        /// Calculates the subtotal.
        /// Allows overriding
        /// </summary>
        /// <returns>The subtotal = Price * Quantity</returns>
        public virtual decimal GetSubTotal()
        {
            //calculate the subtotal and return it
            // new NotImplementedException();
            return Price * Quantity;
        }

        /// <summary>
        /// Add the quantity
        /// </summary>
        /// <param name="product">The product to add its quantity</param>
        /// <returns>If the two inputs are the same product, then return the first after adding the quantity. 
        /// If not same product, throw an Exception</returns>
        public virtual Product Add(Product product1)
        {
            // Check if the products are same
            if (product1.ProductId != this.ProductId)
                throw new Exception("Can't add two different products.");
            this.Quantity += product1.Quantity;
            return product1;
        }

        /// <summary>
        /// Deduct the quantity
        /// </summary>
        /// <param name="product">The product to deduct its quantity</param>
        /// <returns>If the two inputs are the same product, then return the first after adding the quantity. 
        /// If not same product, throw an Exception</returns>
        public virtual Product Remove(Product product1)
        {
            // Check if the products are same
            if (product1.ProductId != this.ProductId)
                throw new Exception("Can't subtract two different products.");
            // Check if the quantity is enough
            if (this.Quantity < product1.Quantity)
                throw new ArgumentOutOfRangeException("Quantity",
                    product1.Quantity, "There is not enough quantity.");

            this.Quantity -= product1.Quantity;
            return product1;
        }



        /// <summary>
        /// Overload the "+" operator to add the quantity
        /// </summary>
        /// <param name="product1">The first product to be added</param>
        /// <param name="product2">The second product to be added</param>
        /// <returns>If the two inputs are the same product, then return the first after adding the quantity. 
        /// If not same product, throw an Exception</returns>
        public static Product operator + (Product product1, Product product2)
        {
            // return product1 with the added quantity from product 2;
            //throw new NotImplementedException();
            if (product1.ProductId != product2.ProductId)
                throw new Exception("Can't add two different products.");
            product1.Quantity += product2.Quantity;

            return product1;
        }

        /// <summary>
        /// Overload the "-" operator to subtract the quantity
        /// </summary>
        /// <param name="product1">The first product</param>
        /// <param name="product2">The second product</param>
        /// <returns>If the two inputs are the same product, then return the first after subtracting the quantity of the second. 
        /// If not same product, throw an Exception</returns>
        public static Product operator -(Product product1, Product product2)
        {
            //throw new NotImplementedException();
            if (product1.ProductId != product2.ProductId)
                throw new Exception("Can't subtract two different products.");

            if (product1.Quantity < product2.Quantity)
                throw new ArgumentOutOfRangeException("Quantity","There is not enough quantity.");

            product1.Quantity -= product2.Quantity;
            return product1;

        }
    }
}