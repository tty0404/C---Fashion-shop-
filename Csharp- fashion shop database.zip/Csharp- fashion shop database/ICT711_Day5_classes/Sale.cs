﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace ICT711_Day5_classes
{
    public class Sale : ISale
    {
        public int Id { get; set; }
        public DateTime Date { get; set; }
        public int CustomerId { get; set; }
        public int AssociateId { get; set; }

        public List<Product> ProductsList { get; } = new List<Product>();

        public SaleStatus Status { get; set; }


        public Sale() { }

        public Sale(int custId, int AssoId, SaleStatus SStatus)
        {
            this.CustomerId = custId;
            this.AssociateId = AssoId;
            this.Status = SStatus;
        }
        public Sale(int saleId, DateTime date, int custId, int AssoId, SaleStatus SStatus)
        {
            this.Id = saleId;
            this.Date = date;
            this.CustomerId = custId;
            this.AssociateId = AssoId;
            this.Status = SStatus;
        }




        public int AddProduct(Product AddProduct, IInventory inventory)
        {
            //throw new NotImplementedException();

         
            if (!inventory.Products.Any(p => p.ProductId == AddProduct.ProductId))
            {
                throw new Exception("Product is not in inventory.");
            }


            foreach (Product product in ProductsList)
            {
                
                    if (product.ProductId == AddProduct.ProductId)
                    {

                        if (product is ProductGarment && AddProduct is ProductGarment)
                        {

                            ((ProductGarment)product).Add(AddProduct);

                        }

                        else
                        {
                            product.Quantity += AddProduct.Quantity;
                        }


                        inventory[product.ProductId].Quantity -= AddProduct.Quantity;

                        return AddProduct.Quantity;
                        //break;
                    }
                
            }
            ProductsList.Add(AddProduct);
            return AddProduct.Quantity;
        }

        public decimal GetTotal()
        {
            //throw new NotImplementedException();
            decimal total = ProductsList.Sum(product => product.GetSubTotal());
            return total;
        
        }

        public int RemoveProduct(Product product, IInventory inventory)
        {

            if (product is ProductGarment)
            {
                ProductGarment pg = (ProductGarment)ProductsList.Single(p => p.ProductId == product.ProductId);
                pg -= (ProductGarment)product;
                inventory.RemoveProduct(pg);
            }
            else
            {
                ProductsList.Single(p => p.ProductId == product.ProductId).Quantity -= product.Quantity;
                inventory[product.ProductId].Quantity += product.Quantity;
            }
            return product.Quantity;
        }
  
    }
}