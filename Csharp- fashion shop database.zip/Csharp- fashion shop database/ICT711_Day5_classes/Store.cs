﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Newtonsoft.Json;
//using Newtonsoft.Json.Serialization;

namespace ICT711_Day5_classes
{
    public class Store : IStore
    {
        public string StoreName { get; set; }
        public string Address { get; set; }
        [JsonIgnore]    // Don't store this data inside the store file. Will be stored in a separate file
        public List<ICustomer> Customers { get; set; }
        [JsonIgnore]    // Don't store this data inside the store file. Will be stored in a separate file
        public List<IAssociate> Associates { get; set; }
        [JsonIgnore]    // Don't store this data inside the store file. Will be stored in a separate file
        public Inventory Inventory { get; set; }
        [JsonIgnore]    // Don't store this data inside the store file. Will be stored in a separate file
        public List<ISale> Sales { get; set; }
        [JsonProperty]
        public static string AssociatesFileName { get; set; } = "associates.json";
        [JsonProperty]
        public static string CustomersFileName { get; set; } = "customers.json";
        [JsonProperty]
        public static string InventoryFileName { get; set; } = "inventory.json";
        [JsonProperty]
        public static string SalesFileName { get; set; } = "sales.json";
        [JsonProperty]
        public static string StoreFileName { get; set; } = "store.json";

        public Store()
        {
            
        }

        public Store(string storeName, String address)
        {
            StoreName = storeName;
            Address = address;
        }

        
        public void LoadAssociates()
        {
            //throw new NotImplementedException();
            string jsonString = File.ReadAllText(AssociatesFileName);
            var aso = JsonConvert.DeserializeObject<List<Associate>>(jsonString, new JsonSerializerSettings
            {
                TypeNameHandling = TypeNameHandling.Auto
            });
            Associates = aso.ConvertAll(a => (IAssociate)a);   // Typecasting for each element
            
        }

        public void LoadCustomers()
        {
            //throw new NotImplementedException();
            
            string jsonString = File.ReadAllText(CustomersFileName);
            var st = JsonConvert.DeserializeObject<List<Customer>>(jsonString, new JsonSerializerSettings
            {
                TypeNameHandling = TypeNameHandling.Auto
            });
            Customers = st.ConvertAll(c => (ICustomer)c);   // Typecasting for each element
            //throw new NotImplementedException();
        }

        public void LoadInventory()
        {
            //throw new NotImplementedException();
            string jsonString = File.ReadAllText(InventoryFileName);
            Inventory = JsonConvert.DeserializeObject<Inventory>(jsonString, new JsonSerializerSettings
            {
                TypeNameHandling = TypeNameHandling.Auto
            });
            


        }

        public void LoadSales()
        {
            string jsonString = File.ReadAllText(SalesFileName);
            var ss = JsonConvert.DeserializeObject<List<Sale>>(jsonString, new JsonSerializerSettings
            {
                TypeNameHandling = TypeNameHandling.Auto
            });
            Sales = ss.ConvertAll(s => (ISale)s);   // Typecasting for each element
            //throw new NotImplementedException();
        }

        public void SaveAssociates()
        {
            string jsonString = JsonConvert.SerializeObject(Associates, Formatting.Indented, new JsonSerializerSettings
            {
                TypeNameHandling = TypeNameHandling.Auto
            });
            File.WriteAllText(AssociatesFileName, jsonString);
            return;
            //throw new NotImplementedException();
        }

        public void SaveCustomers()
        {
            //throw new NotImplementedException();
            string jsonString = JsonConvert.SerializeObject(Customers, Formatting.Indented, new JsonSerializerSettings
            {
                TypeNameHandling = TypeNameHandling.Auto
            });
            File.WriteAllText(CustomersFileName, jsonString);
            return;
        }

        public void SaveInventory()
        {   
            //inventory not a list it's an object in this class
            string jsonString = JsonConvert.SerializeObject(Inventory, Formatting.Indented, new JsonSerializerSettings
            {
                TypeNameHandling = TypeNameHandling.Auto
            });
            File.WriteAllText(InventoryFileName, jsonString);
            return;
        }

        public void SaveSales()
        {
            //throw new NotImplementedException();

            string jsonString = JsonConvert.SerializeObject(Sales, Formatting.Indented, new JsonSerializerSettings
            {
                TypeNameHandling = TypeNameHandling.Auto
            });
            File.WriteAllText(SalesFileName, jsonString);
            return;
        }

        public void SaveStoreInfo(string StoreDataFileName = null)
        {
            // throw new NotImplementedException();
            
            //serialize 
            string jsonString = JsonConvert.SerializeObject(this, Formatting.Indented, new JsonSerializerSettings
            {
                TypeNameHandling = TypeNameHandling.Auto
            });

            //deternmine filename
            string fileName = StoreDataFileName ?? StoreFileName;

            //write
            File.WriteAllText(fileName, jsonString);

        }

        public static Store CreateStore()   // Factory method
        {
            if (!File.Exists(StoreFileName))  // in case no file exists
            {
                return new Store("New Store Name", "Somewhere address");
            }
            string jsonString = File.ReadAllText(StoreFileName);
            return JsonConvert.DeserializeObject<Store>(jsonString, new JsonSerializerSettings
            {
                TypeNameHandling = TypeNameHandling.Auto
            });

        }
    }
}