﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ICT711_Day5_classes;
using System;
using System.Collections.Generic;
using System.Text;

namespace ICT711_Day5_classes.Tests
{
    [TestClass()]
    public class AssociateTests
    {
        [TestMethod()]
        public void FNameTest()     // Assignment 2
        {
            // Add FName property to the Person Class
            IAssociate associate = new Associate();

            Assert.IsTrue(associate.HasProperty("FName"));
        }
        [TestMethod()]
        public void LNameTest()     // Assignment 2
        {
            // Add LName property to the Person Class
            IAssociate associate = new Associate();

            Assert.IsTrue(associate.HasProperty("LName"));
        }
        [TestMethod()]
        public void GetFullNameTest()     // Assignment 2
        {
            // Add GetFullName method to the Person Class
            IAssociate associate = new Associate();

            Assert.IsTrue(associate.HasMethod("GetFullName"));
        }

        [TestMethod()]
        public void GetFullNameTest2()     // Assignment 2
        {
            // Full name should return the full user name i.e.: "FName LName"
            IAssociate associate = (IAssociate)new Associate();
            associate.FName = "John";
            associate.LName = "Doe";
            string actrual = associate.GetFullName();
            string expected = "John Doe";
            Assert.AreEqual(expected, actrual);
        }
       
        [TestMethod()]
        public void CreateAssociateTest()     // Assignment 2
        {
            /// Create a new associate with no data
            /// Check the Id is positive integer
            IAssociate associate = (IAssociate)new Associate();
            int actrual = associate.AssociateId;

            Assert.IsInstanceOfType(actrual, typeof(int));
            Assert.IsTrue(actrual >= 0);
        }

        [TestMethod()]
        public void CreateAssociateWithParamatersTest()     // Assignment 2
        {
            /// Create a new associate with data
            /// Check the Id is positive integer, and the data is correct
            IAssociate associate = (IAssociate)new Associate(44,"John", "Smith", "40300000", "w@s.c", "Accounting");
            int actrual = associate.AssociateId;

            Assert.IsInstanceOfType(actrual, typeof(int));
            Assert.AreEqual(actrual, 44);
            Assert.AreEqual("w@s.c", associate.Email);
            Assert.AreEqual("John", associate.FName);
            Assert.AreEqual("Smith", associate.LName);
            Assert.AreEqual("40300000", associate.Tel);
            Assert.AreEqual("Accounting", associate.Department);
        }


        [TestMethod()]
        public void GetManagerTest()
        {
            IAssociate associate1 = (IAssociate)new Associate(44, "John", "Smith", "40300000", "w@s.c", "Accounting");
            IAssociate associate2 = (IAssociate)new Associate(33, "Sam", "T.", "40300000", "w@s.c", "Accounting");
            IAssociate manager = (IAssociate)new Associate(55, "Mike", "Sam", "40300000", "mike@s.c", "Management");
            associate1.ManagerId = manager.AssociateId;
            List<IAssociate> associates = new List<IAssociate>();
            associates.Add(associate1);
            associates.Add(associate2);
            associates.Add(manager);
            string actual = associate1.GetManager(associates);
            string expected = manager.GetFullName();
            Assert.AreEqual(expected, actual);
        }
    }
}