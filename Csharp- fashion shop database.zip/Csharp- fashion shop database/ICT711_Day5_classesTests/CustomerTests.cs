﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ICT711_Day5_classes;
using System;
using System.Collections.Generic;
using System.Text;

namespace ICT711_Day5_classes.Tests
{
    [TestClass()]
    public class CustomerTests
    {
        [TestMethod()]
        public void FNameTest()     // Assignment 2
        {
            // Add FName property to the Person Class
            ICustomer customer = new Customer();

            Assert.IsTrue(customer.HasProperty("FName"));
        }
        [TestMethod()]
        public void LNameTest()     // Assignment 2
        {
            // Add LName property to the Person Class
            ICustomer customer = new Customer();

            Assert.IsTrue(customer.HasProperty("LName"));
        }
        [TestMethod()]
        public void GetFullNameTest()     // Assignment 2
        {
            // Add GetFullName method to the Person Class
            ICustomer customer = new Customer();

            Assert.IsTrue(customer.HasMethod("GetFullName"));
        }

        [TestMethod()]
        public void GetFullNameTest2()     // Assignment 2
        {
            // Full name should return the full user name i.e.: "FName LName"
            ICustomer customer = (ICustomer)new Customer();
            customer.FName = "John";
            customer.LName = "Doe";
            string actrual = customer.GetFullName();
            string expected = "John Doe";
            Assert.AreEqual(expected, actrual);
        }
        [TestMethod()]
        public void RegisteredOnTest()     // Assignment 2
        {
            // Add LName property to the Person Class
            ICustomer customer = new Customer();

            Assert.IsTrue(customer.HasProperty("RegisteredOn"));
            Assert.IsInstanceOfType(customer.RegisteredOn, typeof(DateTime));
            Assert.IsTrue((customer.RegisteredOn - DateTime.Now).TotalSeconds < 1);
        }
        [TestMethod()]
        public void CreateCustomerTest()     // Assignment 2
        {
            /// Create a new customer with no data
            /// Check the Id is positive integer
            ICustomer customer = (ICustomer)new Customer();
            int actrual = customer.CustomerId;
            
            Assert.IsInstanceOfType(actrual, typeof(int));
            Assert.IsTrue(actrual >= 0);
        }

        [TestMethod()]
        public void CreateCustomerWithParamatersTest()     // Assignment 2
        {
            /// Create a new customer with data
            /// Check the Id is positive integer, and the data is correct
            ICustomer customer = (ICustomer)new Customer("John", "Smith", "40300000", "w@s.c");
            int actrual = customer.CustomerId;

            Assert.IsInstanceOfType(actrual, typeof(int));
            Assert.IsTrue(actrual >= 0);
            Assert.AreEqual("w@s.c", customer.Email);
            Assert.AreEqual("John", customer.FName);
            Assert.AreEqual("Smith", customer.LName);
            Assert.AreEqual("40300000",customer.Tel);
            Assert.IsInstanceOfType(customer.RegisteredOn, typeof(DateTime));
            Assert.IsTrue((customer.RegisteredOn - DateTime.Now).TotalSeconds < 1);            
        }

        [TestMethod()]
        public void GetAssociateTest()
        {
            // Checks is the method will return the correct associate name
            ICustomer customer = (ICustomer)new Customer("John", "Smith", "40300000", "w@s.c");
            customer.MainAssociateId = 2;
            List<IAssociate> associates = new List<IAssociate>();
            associates.Add(new Associate(2, "Jim", "Edwin", "", ""));
            associates.Add(new Associate(1, "Mike", "Todd", "", ""));
            
            string actual = customer.GetAssociate(associates);
            string expected = "Jim Edwin";

            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void GetPurchasesTest()
        {
            // This test needs the Sale class to be finished first.
            ICustomer customer = (ICustomer)new Customer("John", "Smith", "40300000", "w@s.c");
            
            List<ISale> sales = new List<ISale>();
            ISale sale = (ISale)new Sale();
            sale.CustomerId = customer.CustomerId;
            sales.Add(sale);
            sale = (ISale)new Sale();
            sale.CustomerId = 0;
            sales.Add(sale);
            sale = (ISale)new Sale();
            sale.CustomerId = customer.CustomerId;
            sales.Add(sale);

            List<ISale> actual = customer.GetPurchases(sales);
            int expectedCount = 2;

            Assert.AreEqual(expectedCount, actual.Count);
            Assert.AreEqual(actual[0].CustomerId, customer.CustomerId);
            Assert.AreEqual(actual[1].CustomerId, customer.CustomerId);
        }
    }
}