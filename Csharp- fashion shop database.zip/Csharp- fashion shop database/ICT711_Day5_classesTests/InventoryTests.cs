﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ICT711_Day5_classes;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace ICT711_Day5_classes.Tests
{
    [TestClass()]
    public class InventoryTests
    {
        [TestMethod()]
        public void AddProductTest()
        {
            // After creating your class, Remove the next line and uncomment the below test code.
            //Assert.Fail();
            
            // Test add product functionality 
            Product product1 = new Product(22, "M Shirt", "Men Shirt", 14.47m, 78);
            Product product2 = new Product(23, "L Shirt", "Ladies Shirt", 17.47m, 12);
            Product product3 = new Product(24, "M Shirt S", "Men Shirt Small", 14.37m, 10);
            Product product4 = new Product(25, "L Shirt S", "Ladies Shirt Small", 17.37m, 11);
            Product product5 = new Product(25, "L Shirt S", "Ladies Shirt Small", 17.37m, 5);
            Inventory inventory = new Inventory();
            inventory.AddProduct(product1);
            Assert.AreEqual(1, inventory.Products.Count);
            inventory.AddProduct(product2);
            Assert.AreEqual(2, inventory.Products.Count);
            inventory.AddProduct(product3);
            Assert.AreEqual(3, inventory.Products.Count);
            inventory.AddProduct(product4);
            Assert.AreEqual(4, inventory.Products.Count);
            // Product already in inventory. Add quantity
            inventory.AddProduct(product5);
            Assert.AreEqual(4, inventory.Products.Count);
            Assert.AreEqual(16, product4.Quantity);        
            
        }

        [TestMethod()]
        public void IndexProductIdTest()
        {
            // After creating your class, Remove the next line and uncomment the below test code.
            //Assert.Fail();
            
            // Indexer with the product Id
            Product product1 = new Product(22, "M Shirt", "Men Shirt", 14.47m, 78);
            Product product2 = new Product(23, "L Shirt", "Ladies Shirt", 17.47m, 12);
            Product product3 = new Product(24, "M Shirt S", "Men Shirt Small", 14.37m, 10);
            Product product4 = new Product(25, "L Shirt S", "Ladies Shirt Small", 17.37m, 11);
            Inventory inventory = new Inventory();
            inventory.AddProduct(product1);
            inventory.AddProduct(product2);
            inventory.AddProduct(product3);
            inventory.AddProduct(product4);
            IProduct expected = product3;
            IProduct actual = inventory[24];
            Assert.AreEqual(expected, actual);
            
        }

        [TestMethod()]
        public void IndexProductNameTest()
        {
            // After creating your class, Remove the next line and uncomment the below test code.
           // Assert.Fail();
            
            // Use part of the product name to retrieve a list of all matches 
            Product product1 = new Product(22, "M Shirt", "Men Shirt", 14.47m, 78);
            Product product2 = new Product(23, "L Shirt", "Ladies Shirt", 17.47m, 12);
            Product product3 = new Product(24, "M Shirt S", "Men Shirt Small", 14.37m, 10);
            Product product4 = new Product(25, "L Shirt S", "Ladies Shirt Small", 17.37m, 11);
            Inventory inventory = new Inventory();
            inventory.AddProduct(product1);
            inventory.AddProduct(product2);
            inventory.AddProduct(product3);
            inventory.AddProduct(product4);
            List<IProduct> expected = new List<IProduct>() { product1, product3 };
            List<IProduct> actual = inventory["M Shirt"];
            Assert.AreEqual(expected.Count, actual.Count);
            Assert.AreEqual(0, actual.Except(expected).Count());
            
        }

        [TestMethod()]
        public void RemoveProductTest()
        {
            // After creating your class, Remove the next line and uncomment the below test code.
            //Assert.Fail();
            
            // Remove product - happy path
            Product product1 = new Product(22, "M Shirt", "Men Shirt", 14.47m, 78);
            Product product2 = new Product(23, "L Shirt", "Ladies Shirt", 17.47m, 12);
            Product product3 = new Product(24, "M Shirt S", "Men Shirt Small", 14.37m, 10);
            Product product4 = new Product(25, "L Shirt S", "Ladies Shirt Small", 17.37m, 11);
            Product product5 = new Product(25, "L Shirt S", "Ladies Shirt Small", 17.37m, 5);
            Inventory inventory = new Inventory();
            inventory.AddProduct(product1);
            inventory.AddProduct(product2);
            inventory.AddProduct(product3);
            inventory.AddProduct(product4);
            Assert.AreEqual(11, inventory[25].Quantity);
            // Product already in inventory. Subtract quantity
            inventory.RemoveProduct(product5);
            Assert.AreEqual(6, inventory[25].Quantity);
            // Make sure the other products are not changed
            Assert.AreEqual(78, inventory[22].Quantity);
            Assert.AreEqual(12, inventory[23].Quantity);
            Assert.AreEqual(10, inventory[24].Quantity);
            
        }

        [TestMethod()]
        public void RemoveProductNotInInventoryTest()
        {
            // After creating your class, Remove the next line and uncomment the below test code.
            //Assert.Fail();
            
            // Remove product not in inventory
            Product product1 = new Product(22, "M Shirt", "Men Shirt", 14.47m, 78);
            Product product2 = new Product(23, "L Shirt", "Ladies Shirt", 17.47m, 12);
            Product product3 = new Product(24, "M Shirt S", "Men Shirt Small", 14.37m, 10);
            Product product4 = new Product(25, "L Shirt S", "Ladies Shirt Small", 17.37m, 11);
            Product product5 = new Product(25, "L Shirt S", "Ladies Shirt Small", 17.37m, 5);
            Inventory inventory = new Inventory();
            inventory.AddProduct(product1);
            inventory.AddProduct(product2);
            inventory.AddProduct(product3);
            string expected = "Product is not in inventory.";
            string actual = "";
            // Product is not in inventory. Exception
            try { inventory.RemoveProduct(product4); }
            catch(Exception e) { actual=e.Message; }
            Assert.AreEqual(expected, actual);
            
        }

        [TestMethod()]
        public void RemoveProductNotEnoughTest()
        {
            // After creating your class, Remove the next line and uncomment the below test code.
            //Assert.Fail();
            
            // Try to remove more quantity than what we have in inventory
            Product product1 = new Product(22, "M Shirt", "Men Shirt", 14.47m, 78);
            Product product2 = new Product(23, "L Shirt", "Ladies Shirt", 17.47m, 12);
            Product product3 = new Product(24, "M Shirt S", "Men Shirt Small", 14.37m, 10);
            Product product4 = new Product(25, "L Shirt S", "Ladies Shirt Small", 17.37m, 11);
            Product product5 = new Product(25, "L Shirt S", "Ladies Shirt Small", 17.37m, 5);
            Inventory inventory = new Inventory();
            inventory.AddProduct(product1);
            inventory.AddProduct(product2);
            inventory.AddProduct(product3);
            inventory.AddProduct(product5);
            string expected = "There is not enough quantity.";
            string actual = "";
            // Product is not in inventory. Exception
            try { inventory.RemoveProduct(product4); }
            catch (ArgumentOutOfRangeException e) { actual = e.Message; }
            Assert.AreEqual(expected, actual.Substring(0, expected.Length));
            
        }

        [TestMethod()]
        public void PlusOperatorTest()
        {
            // After creating your class, Remove the next line and uncomment the below test code.
            //Assert.Fail();
            
                        
            // Test add product functionality 
            Product product1 = new Product(22, "M Shirt", "Men Shirt", 14.47m, 78);
            Product product2 = new Product(23, "L Shirt", "Ladies Shirt", 17.47m, 12);
            Product product3 = new Product(24, "M Shirt S", "Men Shirt Small", 14.37m, 10);
            Product product4 = new Product(25, "L Shirt S", "Ladies Shirt Small", 17.37m, 11);
            Product product5 = new Product(25, "L Shirt S", "Ladies Shirt Small", 17.37m, 5);
            Inventory inventory = new Inventory();
            inventory += product1;
            Assert.AreEqual(1, inventory.Products.Count);
            inventory += (product2);
            Assert.AreEqual(2, inventory.Products.Count);
            inventory += (product3);
            Assert.AreEqual(3, inventory.Products.Count);
            inventory += (product4);
            Assert.AreEqual(4, inventory.Products.Count);
            // Product already in inventory. Add quantity
            inventory += (product5);
            Assert.AreEqual(4, inventory.Products.Count);
            Assert.AreEqual(16, product4.Quantity);
            
        }

        [TestMethod()]
        public void MinusOperatorTest()
        {
            // After creating your class, Remove the next line and uncomment the below test code.
            //Assert.Fail();
            
            // Remove product using "-" - happy path
            Product product1 = new Product(22, "M Shirt", "Men Shirt", 14.47m, 78);
            Product product2 = new Product(23, "L Shirt", "Ladies Shirt", 17.47m, 12);
            Product product3 = new Product(24, "M Shirt S", "Men Shirt Small", 14.37m, 10);
            Product product4 = new Product(25, "L Shirt S", "Ladies Shirt Small", 17.37m, 11);
            Product product5 = new Product(25, "L Shirt S", "Ladies Shirt Small", 17.37m, 5);
            Inventory inventory = new Inventory();
            inventory.AddProduct(product1);
            inventory.AddProduct(product2);
            inventory.AddProduct(product3);
            inventory.AddProduct(product4);
            Assert.AreEqual(11, inventory[25].Quantity);
            // Product already in inventory. Subtract quantity
            inventory -= (product5);
            Assert.AreEqual(6, inventory[25].Quantity);
            // Make sure the other products are not changed
            Assert.AreEqual(78, inventory[22].Quantity);
            Assert.AreEqual(12, inventory[23].Quantity);
            Assert.AreEqual(10, inventory[24].Quantity);
            
        }

        [TestMethod()]
        public void RemoveProductGarmentTest()
        {
            // After creating your class, Remove the next line and uncomment the below test code.
            // You must do this test after we finish the Polymorphism and do the ProductGarment class
            //Assert.Fail();
            
            // Remove product - happy path
            ProductGarment product1 = new ProductGarment(22, "Shirt", "Men Shirt");
            product1.AddQuantity("S", 10, 15.0m);
            product1.AddQuantity("M", 20, 20.0m);
            product1.AddQuantity("L", 5, 10.0m);
            ProductGarment product2 = new ProductGarment(22, "Shirt", "Men Shirt");
            product2.AddQuantity("S", 2, 15.0m);
            product2.AddQuantity("M", 3, 20.0m);
            product2.AddQuantity("L", 5, 10.0m);
            Inventory inventory = new Inventory();
            inventory.AddProduct(product1);
            Assert.AreEqual(10, ((ProductGarment)inventory[22]).SizePriceQuantity["S"].quantity);
            // Product already in inventory. Subtract quantity
            inventory.RemoveProduct(product2);
            
            Assert.AreEqual(8, ((ProductGarment)inventory[22]).SizePriceQuantity["S"].quantity);
            Assert.AreEqual(17, ((ProductGarment)inventory[22]).SizePriceQuantity["M"].quantity);
            Assert.AreEqual(0, ((ProductGarment)inventory[22]).SizePriceQuantity["L"].quantity);

        }
    }
}