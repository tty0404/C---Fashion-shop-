﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ICT711_Day5_classes.Tests
{
    public static class ObjectExtension
    {
        public static bool HasProperty(this object obj, string propertyName)
        {
            return obj.GetType().GetProperty(propertyName) != null;
        }
        // Check for Methods
        public static bool HasMethod(this object obj, string methodName)
        {
            return obj.GetType().GetMethod(methodName) != null;
        }
    }
}
