﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ICT711_Day5_classes;
using System;
using System.Collections.Generic;
using System.Text;

namespace ICT711_Day5_classes.Tests
{
    [TestClass()]
    public class ProductGarmentTests
    {
        [TestMethod()]
        public void ProductGarmentTest()     // Assignment 2
        {
            // The ProductId is non negative integer
            IProduct product = new ProductGarment();
            Assert.IsInstanceOfType(product.ProductId, typeof(int));
            Assert.IsTrue(product.ProductId >= 0);
        }

        [TestMethod()]
        public void ProductGarmentConstructorParametrizedTest()
        {
            // The ProductId is non negative integer
            ProductGarment product = new ProductGarment("Shirt", "Men Shirt");
            // Check ProductId
            Assert.IsInstanceOfType(product.ProductId, typeof(int));
            Assert.IsTrue(product.ProductId >= 0);

            Assert.AreEqual("Shirt", product.ProductName);  // Check product name
            Assert.AreEqual("Men Shirt", product.Description);// Description
            Assert.AreEqual(0m, product.Price);         // Price
            Assert.AreEqual(0, product.Quantity);       // Quantity
        }

        [TestMethod()]
        public void ProductGarmentConstructorParametrizedWithIdTest()
        {
            // Set ProductId
            ProductGarment product = new ProductGarment(22, "Shirt", "Men Shirt");
            
            // Check ProductId
            Assert.IsInstanceOfType(product.ProductId, typeof(int));
            Assert.IsTrue(product.ProductId == 22);

            Assert.AreEqual("Shirt", product.ProductName);  // Check product name
            Assert.AreEqual("Men Shirt", product.Description);// Description
            Assert.AreEqual(0m, product.Price);         // Price
            Assert.AreEqual(0, product.Quantity);       // Quantity
        }

        [TestMethod()]
        public void ProductGarmentCloningConstructorTest()
        {
            // Create object to clone it
            ProductGarment product = new ProductGarment("Shirt", "Men Shirt");
            ProductGarment clonedProduct = (ProductGarment)product.Clone();
            Assert.AreNotEqual(product, clonedProduct);     // make sure they are different objects

            Assert.AreEqual(product.ProductId, clonedProduct.ProductId);     // Check ProductId
            Assert.AreEqual(product.ProductName, clonedProduct.ProductName); // Check product name
            Assert.AreEqual(product.Description, clonedProduct.Description); // Description
        }

        [TestMethod()]
        public void GetSubTotalTest()
        {
            ProductGarment product = new ProductGarment(22, "Shirt", "Men Shirt");
            product.AddQuantity("S", 10, 15.0m);
            product.AddQuantity("M", 20, 20.0m);
            product.AddQuantity("L", 5, 10.0m);
            decimal expected = 600.0m;
            decimal actual = product.GetSubTotal();     
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void PlusOperatorTest()
        {
            // Check correct addition. i.e. the two products are same
            ProductGarment product1 = new ProductGarment(22, "Shirt", "Men Shirt");
            ProductGarment product2 = new ProductGarment(22, "Shirt", "Men Shirt");
            product1.AddQuantity("S", 10, 15.0m);
            product1.AddQuantity("M", 20, 20.0m);
            product2.AddQuantity("S", 5, 15.0m);
            int expected = 15;
            int actual = (product1 + product2).SizePriceQuantity["S"].quantity;
            Assert.AreEqual(expected, actual);
            actual = product1.SizePriceQuantity["M"].quantity;
            Assert.AreEqual(20, actual);
        }

        [TestMethod()]
        public void PlusOperatorWrongTest()
        {
            // Check wrong addition. i.e. the two products are different
            ProductGarment product1 = new ProductGarment(22, "M Shirt", "Men Shirt");
            ProductGarment product2 = new ProductGarment(23, "L Shirt", "Ladies Shirt");
            product1.AddQuantity("S", 10, 15.0m);
            product1.AddQuantity("M", 20, 20.0m);
            product2.AddQuantity("S", 5, 15.0m);
            string expected = "Can't add two different products.";
            string actual = "";
            try { product1 += product2; }
            catch (Exception e) { actual = e.Message; }
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void MinusOperatorTest()
        {
            // Check correct subtraction. i.e. the two products are same with enough quantity
            ProductGarment product1 = new ProductGarment(22, "Shirt", "Men Shirt");
            ProductGarment product2 = new ProductGarment(22, "Shirt", "Men Shirt");
            product1.AddQuantity("S", 10, 15.0m);
            product1.AddQuantity("M", 20, 20.0m);
            product2.AddQuantity("S", 5, 15.0m);
            int expected = 5;
            int actual = (product1 - product2).SizePriceQuantity["S"].quantity;
            Assert.AreEqual(expected, actual);
            actual = product1.SizePriceQuantity["M"].quantity;
            Assert.AreEqual(20, actual);
        }

        [TestMethod()]
        public void MinusOperatorWrongTest()
        {
            // Check wrong subtraction. i.e. the two products are different
            ProductGarment product1 = new ProductGarment(22, "M Shirt", "Men Shirt");
            ProductGarment product2 = new ProductGarment(23, "L Shirt", "Ladies Shirt");
            product1.AddQuantity("S", 10, 15.0m);
            product1.AddQuantity("M", 20, 20.0m);
            product2.AddQuantity("S", 5, 15.0m);
            string expected = "Can't subtract two different products.";
            string actual = "";
            try { product1 -= product2; }
            catch (Exception e) { actual = e.Message; }
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void MinusOperatorWrongQuantityTest()
        {
            // Check wrong quantity subtraction. i.e. would result in negative quantity
            ProductGarment product1 = new ProductGarment(22, "M Shirt", "Men Shirt");
            ProductGarment product2 = new ProductGarment(22, "M Shirt", "Men Shirt");
            product1.AddQuantity("S", 10, 15.0m);
            product1.AddQuantity("M", 20, 20.0m);
            product2.AddQuantity("S", 5, 15.0m);
            string expected = "There is not enough quantity.";
            string actual = "";
            try { product2 -= product1; }
            catch (ArgumentOutOfRangeException e) { actual = e.Message; }
            Assert.AreEqual(expected, actual.Substring(0, expected.Length));
        }

    }
}