﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ICT711_Day5_classes;
using System;
using System.Collections.Generic;
using System.Text;

namespace ICT711_Day5_classes.Tests
{
    [TestClass()]
    public class ProductTests
    {
        [TestMethod()]
        public void ProductConstructorTest()     // Assignment 2
        {
            // The ProductId is non negative integer
            IProduct product = new Product();
            Assert.IsInstanceOfType(product.ProductId, typeof(int));
            Assert.IsTrue(product.ProductId >= 0);
            
        }

        [TestMethod()]
        public void ProductConstructorParametrizedTest()     // Assignment 2
        {
            // The ProductId is non negative integer
            IProduct product = new Product("Shirt", "Men Shirt", 14.47m, 78);
            // Check ProductId
            Assert.IsInstanceOfType(product.ProductId, typeof(int));
            Assert.IsTrue(product.ProductId >= 0);

            Assert.AreEqual("Shirt", product.ProductName);  // Check product name
            Assert.AreEqual("Men Shirt", product.Description);// Description
            Assert.AreEqual(14.47m, product.Price);         // Price
            Assert.AreEqual(78, product.Quantity);          // Quantity
            
        }

        [TestMethod()]
        public void ProductConstructorParametrizedWithIdTest()     // Assignment 2
        {            
            // Set ProductId
            IProduct product = new Product(22, "Shirt", "Men Shirt", 14.47m, 78);
            // Check ProductId
            Assert.IsInstanceOfType(product.ProductId, typeof(int));
            Assert.IsTrue(product.ProductId == 22);

            Assert.AreEqual("Shirt", product.ProductName);  // Check product name
            Assert.AreEqual("Men Shirt", product.Description);// Description
            Assert.AreEqual(14.47m, product.Price);         // Price
            Assert.AreEqual(78, product.Quantity);          // Quantity           
        }

        [TestMethod()]
        public void ProductCloningConstructorTest()
        {            
            // Create object to clone it
            Product product = new Product("Shirt", "Men Shirt", 14.47m, 78);
            IProduct clonedProduct = new Product(product);
            Assert.AreNotEqual(product, clonedProduct);     // make sure they are different objects

            Assert.AreEqual(product.ProductId, clonedProduct.ProductId);     // Check ProductId
            Assert.AreEqual(product.ProductName, clonedProduct.ProductName); // Check product name
            Assert.AreEqual(product.Description, clonedProduct.Description); // Description
            Assert.AreEqual(product.Price, clonedProduct.Price);             // Price
            Assert.AreEqual(product.Quantity, clonedProduct.Quantity);       // Quantity
            
        }

        [TestMethod()]
        public void GetSubTotalTest()
        {          
            IProduct product = new Product(22, "Shirt", "Men Shirt", 14.47m, 78);
            decimal expected = 78 * 14.47m;
            decimal actual = product.GetSubTotal();
            Assert.AreEqual(expected, actual);           
        }

        [TestMethod()]
        public void PlusOperatorTest()
        {            
            // Check correct addition. i.e. the two products are same
            Product product1 = new Product(22, "Shirt", "Men Shirt", 14.47m, 78);
            Product product2 = new Product(22, "Shirt", "Men Shirt", 14.47m, 12);
            int expected = 90;
            int actual = (product1 + product2).Quantity;
            Assert.AreEqual(expected, actual);            
        }

        [TestMethod()]
        public void PlusOperatorWrongTest()
        {
            // Check wrong addition. i.e. the two products are different
            Product product1 = new Product(22, "M Shirt", "Men Shirt", 14.47m, 78);
            Product product2 = new Product(23, "L Shirt", "Ladies Shirt", 17.47m, 12);
            string expected = "Can't add two different products.";
            string actual = "";
            try { product1 += product2; }
            catch (Exception e) { actual = e.Message; }
            Assert.AreEqual(expected, actual);            
        }

        [TestMethod()]
        public void MinusOperatorTest()
        {            
            // Check correct subtraction. i.e. the two products are same with enough quantity
            Product product1 = new Product(22, "Shirt", "Men Shirt", 14.47m, 78);
            Product product2 = new Product(22, "Shirt", "Men Shirt", 14.47m, 12);
            int expected = 66;
            int actual = (product1 - product2).Quantity;
            Assert.AreEqual(expected, actual);           
        }

        [TestMethod()]
        public void MinusOperatorWrongTest()
        {            
            // Check wrong subtraction. i.e. the two products are different
            Product product1 = new Product(22, "M Shirt", "Men Shirt", 14.47m, 78);
            Product product2 = new Product(23, "L Shirt", "Ladies Shirt", 17.47m, 12);
            string expected = "Can't subtract two different products.";
            string actual = "";
            try { product1 -= product2; }
            catch (Exception e) { actual = e.Message; }
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void MinusOperatorWrongQuantityTest()
        {
            // Check wrong quantity subtraction. i.e. would result in negative quantity
            Product product1 = new Product(22, "M Shirt", "Men Shirt", 14.47m, 78);
            Product product2 = new Product(22, "M Shirt", "Men Shirt", 14.47m, 12);
            string expected = "There is not enough quantity.";
            string actual = "";
            try { product2 -= product1; }
            catch (ArgumentOutOfRangeException e) { actual = e.Message; }
            Assert.AreEqual(expected, actual.Substring(0, expected.Length));
        }
    }
}