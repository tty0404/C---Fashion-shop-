﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ICT711_Day5_classes;
using System;
using System.Collections.Generic;
using System.Text;

namespace ICT711_Day5_classes.Tests
{
    [TestClass()]
    public class SaleTests
    {
        [TestMethod()]
        public void SaleConstructorTest()
        {
            // After creating your class, Remove the next line and uncomment the below test code.
            //Assert.Fail();
            
            // The Sale Id is non-negative integer
            ISale sale = new Sale();
            Assert.IsInstanceOfType(sale.Id, typeof(int));
            Assert.IsTrue(sale.Id >= 0);
            
        }

        [TestMethod()]
        public void SaleConstructorParametrizedTest()
        {
            // After creating your class, Remove the next line and uncomment the below test code.
            //Assert.Fail();
            
            // The Sale Id is non negative integer
            ISale sale = new Sale(4, 1, SaleStatus.Returned);
            // Check Id
            Assert.IsInstanceOfType(sale.Id, typeof(int));
            Assert.IsTrue(sale.Id >= 0);
            Assert.AreEqual(4, sale.CustomerId);        // CustomerId
            Assert.AreEqual(1, sale.AssociateId);       // AssociateId
            Assert.AreEqual(SaleStatus.Returned, sale.Status); // Status
            
        }

        [TestMethod()]
        public void SaleConstructorParametrizedWithIdTest()
        {
            // After creating your class, Remove the next line and uncomment the below test code.
            //Assert.Fail();
            
            // Set Sale Id
            ISale sale = new Sale(550, new DateTime(2020, 10, 1), 4, 1, SaleStatus.Returned);
            // Check Sale Id
            Assert.IsInstanceOfType(sale.Id, typeof(int));
            Assert.IsTrue(sale.Id == 550);
            Assert.AreEqual(0, new DateTime(2020, 10, 1).CompareTo(sale.Date)); // Date
            Assert.AreEqual(4, sale.CustomerId);        // CustomerId
            Assert.AreEqual(1, sale.AssociateId);       // AssociateId
            Assert.AreEqual(SaleStatus.Returned, sale.Status); // Status
            
        }

        [TestMethod()]
        public void AddProductTest()
        {
            // After creating your class, Remove the next line and uncomment the below test code.
            //Assert.Fail();
            
            ISale sale = new Sale(550, new DateTime(2020, 10, 1), 4, 1, SaleStatus.Returned);
            Product product1 = new Product(22, "M Shirt", "Men Shirt", 14.47m, 78);
            Product product2 = new Product(23, "L Shirt", "Ladies Shirt", 17.47m, 12);
            Product product3 = new Product(24, "M Shirt S", "Men Shirt Small", 14.37m, 10);
            Product product4 = new Product(25, "L Shirt S", "Ladies Shirt Small", 17.37m, 11);
            Inventory inventory = new Inventory();
            inventory.AddProduct(product1);
            inventory.AddProduct(product2);
            inventory.AddProduct(product3);
            inventory.AddProduct(product4);

            sale.AddProduct(new Product((Product)inventory[22]) { Quantity = 3 }, inventory);
            sale.AddProduct(new Product((Product)inventory[23]) { Quantity = 2 }, inventory);
            Assert.AreEqual(2, sale.ProductsList.Count);
            Assert.AreEqual(23, sale.ProductsList[1].ProductId);
            Assert.AreEqual(75, inventory[22].Quantity);    // Make sure the sold quantity is deducted from inventory
            Assert.AreEqual(10, inventory[23].Quantity);    // Make sure the sold quantity is deducted from inventory
            
        }

        [TestMethod()]
        public void GetTotalTest()
        {
            // After creating your class, Remove the next line and uncomment the below test code.
            //Assert.Fail();
            
            ISale sale = new Sale(550, new DateTime(2020, 10, 1), 4, 1, SaleStatus.Returned);
            Product product1 = new Product(22, "M Shirt", "Men Shirt", 14.47m, 78);
            Product product2 = new Product(23, "L Shirt", "Ladies Shirt", 17.47m, 12);
            Product product3 = new Product(24, "M Shirt S", "Men Shirt Small", 14.37m, 10);
            Product product4 = new Product(25, "L Shirt S", "Ladies Shirt Small", 17.37m, 11);
            Inventory inventory = new Inventory();
            inventory.AddProduct(product1);
            inventory.AddProduct(product2);
            inventory.AddProduct(product3);
            inventory.AddProduct(product4);

            sale.AddProduct(new Product((Product)inventory[22]) { Quantity = 3 }, inventory);
            sale.AddProduct(new Product((Product)inventory[23]) { Quantity = 2 }, inventory);
            decimal expected = product1.Price * 3 + product2.Price * 2;
            decimal actual = sale.GetTotal();
            Assert.AreEqual(expected, actual);
            
        }

        [TestMethod()]
        public void RemoveProductTest()
        {
            // After creating your class, Remove the next line and uncomment the below test code.
            //Assert.Fail();
            
            ISale sale = new Sale(550, new DateTime(2020, 10, 1), 4, 1, SaleStatus.Returned);
            Product product1 = new Product(22, "M Shirt", "Men Shirt", 14.47m, 78);
            Product product2 = new Product(23, "L Shirt", "Ladies Shirt", 17.47m, 12);
            Product product3 = new Product(24, "M Shirt S", "Men Shirt Small", 14.37m, 10);
            Product product4 = new Product(25, "L Shirt S", "Ladies Shirt Small", 17.37m, 11);
            Inventory inventory = new Inventory();
            inventory.AddProduct(product1);
            inventory.AddProduct(product2);
            inventory.AddProduct(product3);
            inventory.AddProduct(product4);

            sale.AddProduct(new Product((Product)inventory[22]) { Quantity = 3 }, inventory);
            sale.AddProduct(new Product((Product)inventory[23]) { Quantity = 2 }, inventory);

            sale.RemoveProduct(new Product((Product)inventory[23]) { Quantity = 1 }, inventory);
            Assert.AreEqual(2, sale.ProductsList.Count);
            Assert.AreEqual(23, sale.ProductsList[1].ProductId);
            Assert.AreEqual(1, sale.ProductsList[1].Quantity);
            Assert.AreEqual(75, inventory[22].Quantity);    // Make sure the sold quantity is deducted from inventory
            Assert.AreEqual(11, inventory[23].Quantity);    // Make sure the updated sold quantity is deducted from inventory
            
        }
        [TestMethod()]
        public void RemoveProductGarmentTest()
        {
            // After creating your class, Remove the next line and uncomment the below test code.
            // You must do this test after we finish the Polymorphism and do the ProductGarment class
            //Assert.Fail();
            
            ISale sale = new Sale(550, new DateTime(2020, 10, 1), 4, 1, SaleStatus.Returned);
            ProductGarment product3 = new ProductGarment(24, "M Shirt S", "Men Shirt Small");
            product3.AddQuantity("S", 10, 15.0m);
            ProductGarment product4 = new ProductGarment(24, "M Shirt S", "Men Shirt Small");
            product4.AddQuantity("S", 30, 15.0m);
            product4.AddQuantity("L", 30, 41.0m);
            Inventory inventory = new Inventory();
            inventory.AddProduct(product4);

            sale.AddProduct(product3, inventory);
            Assert.AreEqual(1, sale.ProductsList.Count);//pass
            Assert.AreEqual(24, sale.ProductsList[0].ProductId);//pass
            Assert.AreEqual(10, ((ProductGarment)sale.ProductsList[0]).SizePriceQuantity["S"].quantity); //detected 0

            sale.AddProduct(product3, inventory);
            Assert.AreEqual(1, sale.ProductsList.Count); //detected 2
            Assert.AreEqual(20, ((ProductGarment)sale.ProductsList[0]).SizePriceQuantity["S"].quantity); //pass

            ProductGarment product5 = new ProductGarment(24, "M Shirt S", "Men Shirt Small");
            product5.AddQuantity("S", 5, 15.0m);
            sale.RemoveProduct(product5, inventory);
            Assert.AreEqual(15, ((ProductGarment)sale.ProductsList[0]).SizePriceQuantity["S"].quantity);//pass

            Assert.AreEqual(15, ((ProductGarment)inventory[24]).SizePriceQuantity["S"].quantity);    // Make sure the updated sold quantity is deducted from inventory
            
        }
    }
}