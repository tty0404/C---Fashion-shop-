﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ICT711_Day5_classes;
using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace ICT711_Day5_classes.Tests
{
    [TestClass()]
    public class StoreTests
    {
        [TestMethod()]
        public void SaveAssociatesTest()
        {
            // After creating your class, Remove the next line and uncomment the below test code.
            //Assert.Fail();

            IAssociate associate1 = (IAssociate)new Associate(1, "John", "Smith", "40300000", "w@s.c", "Manager", "Store manager");
            IAssociate associate2 = (IAssociate)new Associate(78, "Mike", "M", "40377777", "tyy@s.c", "Finance", "Finance associate", 1);
            IAssociate associate3 = (IAssociate)new Associate(4786, "Sam", "T", "40344444", "asd@s.c", "Sales", "Store sales", 1);
            IAssociate associate4 = (IAssociate)new Associate(47851, "Jim", "W", "40388888", "rrr@s.c", "Marketing", "Marketing associate", 1);

            IStore store = new Store() { Associates = new List<IAssociate>() { associate1, associate2, associate3, associate4 } };

            store.SaveAssociates();

            int expected = 1155;
            int actual = File.ReadAllBytes(Store.AssociatesFileName).Length;
            Assert.IsTrue(Math.Abs(expected - actual) < 10);

        }

        [TestMethod()]
        public void SaveCustomersTest()
        {
            // After creating your class, Remove the next line and uncomment the below test code.
            //Assert.Fail();

            Customer customer1 = new Customer(100, "John", "Smith", "40300000", "w@s.c");
            Customer customer2 = new Customer(110, "Mike", "Todd", "40355555", "hjk@s.c");
            Customer customer3 = new Customer(150, "Eddy", "Sam", "403777777", "dgfcg@s.c");
            Customer customer4 = new Customer(177, "July", "Jack", "40399999", "ddd@server.c");
            IStore store = new Store() { Customers = new List<ICustomer>() { customer1, customer2, customer3, customer4 } };

            store.SaveCustomers();

            int expected = 1125;    // 1072
            int actual = File.ReadAllBytes(Store.CustomersFileName).Length;
            Assert.IsTrue(Math.Abs(expected - actual) < 10);

        }

        [TestMethod()]
        public void SaveSalesTest()
        {
            // After creating your class, Remove the next line and uncomment the below test code.
            //Assert.Fail();
            Product product1 = new Product(22, "M Shirt", "Men Shirt", 14.47m, 78);
            Product product2 = new Product(23, "L Shirt", "Ladies Shirt", 17.47m, 12);
            Product product3 = new Product(24, "M Shirt S", "Men Shirt Small", 14.37m, 10);
            ProductGarment product4 = new ProductGarment(25, "Ladies Shirt", "Ladies Shirt M1");
            ProductGarment product5 = new ProductGarment(26, "L Shirt", "Ladies Shirt M2");
            product4.AddQuantity("S", 10, 15.0m);
            product4.AddQuantity("M", 20, 20.0m);
            product5.AddQuantity("S", 5, 15.0m);
            product5.AddQuantity("M", 7, 19.0m);
            product5.AddQuantity("S", 10, 15.0m);

            Inventory inventory = new Inventory();
            inventory.AddProduct(product1);
            inventory.AddProduct(product2);
            inventory.AddProduct(product3);
            inventory.AddProduct(product4);
            inventory.AddProduct(product5);

            ISale sale1 = new Sale(550, new DateTime(2020, 10, 1), 4, 1, SaleStatus.Returned);
            sale1.AddProduct(new Product((Product)inventory[22]) { Quantity = 3 }, inventory);
            sale1.AddProduct(new Product((Product)inventory[23]) { Quantity = 2 }, inventory);
            sale1.AddProduct(new Product((Product)inventory[24]) { Quantity = 4 }, inventory);
            ISale sale2 = new Sale(555, new DateTime(2020, 10, 10), 4, 1, SaleStatus.Complete);
            sale2.AddProduct(new Product((Product)inventory[22]) { Quantity = 1 }, inventory);
            sale2.AddProduct(new Product((Product)inventory[23]) { Quantity = 2 }, inventory);
            ProductGarment prod1 = (ProductGarment)((ProductGarment)inventory[25]).Clone();
            prod1.SizePriceQuantity.Clear();
            prod1.AddQuantity("S", 2, 15.0m);
            prod1.AddQuantity("M", 1, 20.0m);
            sale2.AddProduct(prod1, inventory);
            ProductGarment prod2 = (ProductGarment)((ProductGarment)inventory[26]).Clone();
            prod2.SizePriceQuantity.Clear();
            prod2.AddQuantity("S", 3, 15.0m);
            prod2.AddQuantity("M", 4, 19.0m);
            sale2.AddProduct(prod2, inventory);

            IStore store = new Store() { Sales = new List<ISale>() { sale1, sale2 } };
            store.SaveSales();

            int expected = 2217;
            int actual = File.ReadAllBytes(Store.SalesFileName).Length;
            Assert.IsTrue(Math.Abs(expected - actual) < 10);
            
        }

        [TestMethod()]
        public void SaveInventoryTest()
        {
            // After creating your class, Remove the next line and uncomment the below test code.
            //Assert.Fail();
            
            Product product1 = new Product(22, "M Shirt", "Men Shirt", 14.47m, 78);
            Product product2 = new Product(23, "L Shirt", "Ladies Shirt", 17.47m, 12);
            Product product3 = new Product(24, "M Shirt S", "Men Shirt Small", 14.37m, 10);
            ProductGarment product4 = new ProductGarment(25, "Ladies Shirt", "Ladies Shirt M1");
            ProductGarment product5 = new ProductGarment(26, "L Shirt", "Ladies Shirt M2");
            product4.AddQuantity("S", 10, 15.0m);
            product4.AddQuantity("M", 20, 20.0m);
            product5.AddQuantity("S", 5, 15.0m);
            product5.AddQuantity("M", 7, 19.0m);
            product5.AddQuantity("S", 10, 15.0m);

            Inventory inventory = new Inventory();
            inventory.AddProduct(product1);
            inventory.AddProduct(product2);
            inventory.AddProduct(product3);
            inventory.AddProduct(product4);
            inventory.AddProduct(product5);

            IStore store = new Store() { Inventory = inventory };
            store.SaveInventory();

            int expected = 1358;
            int actual = File.ReadAllBytes(Store.InventoryFileName).Length;
            Assert.IsTrue(Math.Abs(expected - actual) < 10);
            
        }


        [TestMethod()]
        public void SaveStoreInfo()
        {
            // After creating your class, Remove the next line and uncomment the below test code.
            //Assert.Fail();
            
            Product product1 = new Product(22, "M Shirt", "Men Shirt", 14.47m, 78);
            Inventory inventory = new Inventory();
            inventory.AddProduct(product1);

            IStore store = new Store() { Inventory = inventory, StoreName = "New Store Name", Address = "Somewhere address" };
            store.Associates = new List<IAssociate>() { new Associate() { AssociateId = 2 } };
            store.Customers = new List<ICustomer>() { new Customer(100, "John", "Smith", "40300000", "w@s.c") };

            store.SaveStoreInfo();

            string stringContents = File.ReadAllText(Store.StoreFileName);
            Assert.IsTrue(stringContents.Contains("New Store Name"));
            Assert.IsTrue(stringContents.Contains("Somewhere address"));
            Assert.IsTrue(!stringContents.Contains("CustomerId"));   // Should not include customer information 
            Assert.IsTrue(!stringContents.Contains("Products"));   // Should not include inventory information 
            Assert.IsTrue(!stringContents.Contains("AssociateId"));   // Should not include Associates information 
            Assert.IsTrue(!stringContents.Contains("ProductsList"));   // Should not include Sales information 
            Assert.IsTrue(stringContents.Length < 500);
            
        }

        [TestMethod()]
        public void LoadAssociatesTest()
        {
            // After creating your class, Remove the next line and uncomment the below test code.
            //Assert.Fail();

            IStore store = new Store();
            store.LoadAssociates();
            Assert.AreEqual(4, store.Associates.Count);
            Assert.AreEqual(1, store.Associates[0].AssociateId);
            Assert.AreEqual(78, store.Associates[1].AssociateId);
            Assert.AreEqual("Sam", store.Associates[2].FName);
            Assert.AreEqual("40388888", store.Associates[3].Tel);
            Assert.AreEqual("Marketing", store.Associates[3].Department);
            Assert.AreEqual(1, store.Associates[2].ManagerId);

        }

        [TestMethod()]
        public void LoadCustomersTest()
        {
            // After creating your class, Remove the next line and uncomment the below test code.
            //Assert.Fail();

            IStore store = new Store();
            store.LoadCustomers();
            Assert.AreEqual(4, store.Customers.Count);
            Assert.AreEqual(100, store.Customers[0].CustomerId);
            Assert.AreEqual(110, store.Customers[1].CustomerId);
            Assert.AreEqual("Eddy", store.Customers[2].FName);
            Assert.AreEqual("40399999", store.Customers[3].Tel);

        }

        [TestMethod()]
        public void LoadSalesTest()
        {
            // After creating your class, Remove the next line and uncomment the below test code.
            //Assert.Fail();

            IStore store = new Store();
            store.LoadSales();
            Assert.AreEqual(2, store.Sales.Count);
            Assert.AreEqual(4, store.Sales[0].CustomerId);
            Assert.AreEqual(1, store.Sales[0].AssociateId);
            Assert.AreEqual(3, store.Sales[0].ProductsList.Count);
            Assert.AreEqual(4, store.Sales[1].ProductsList.Count);
            Assert.AreEqual("Men Shirt", store.Sales[1].ProductsList[0].Description);
            Assert.AreEqual(17.47m, store.Sales[1].ProductsList[1].Price);
            Assert.IsInstanceOfType(store.Sales[1].ProductsList[2], typeof(ProductGarment));

        }

        [TestMethod()]
        public void LoadInventoryTest()
        {
            // After creating your class, Remove the next line and uncomment the below test code.
            //Assert.Fail();
            
            IStore store = new Store();
            store.LoadInventory();
            Assert.AreEqual(5, store.Inventory.Products.Count);
            Assert.AreEqual("Men Shirt", store.Inventory[22].Description);
            Assert.AreEqual("Ladies Shirt", store.Inventory[25].ProductName);
            Assert.AreEqual(17.47m, store.Inventory[23].Price);
            Assert.AreEqual(10, store.Inventory[24].Quantity);
            Assert.IsInstanceOfType(store.Inventory[25], typeof(ProductGarment));
            Assert.IsInstanceOfType(store.Inventory[26], typeof(ProductGarment));
            Assert.AreEqual(2, ((ProductGarment)store.Inventory[26]).SizePriceQuantity.Count);
            Assert.AreEqual(358.0m, ((ProductGarment)store.Inventory[26]).GetSubTotal());
            
        }

        [TestMethod()]
        public void CreateStoreTest()
        {
            Store store = Store.CreateStore();
            string Expect_StoreName = "New Store Name", Expect_Address = "Somewhere address";
            Assert.AreEqual(Expect_StoreName, store.StoreName);
            Assert.AreEqual(Expect_Address, store.Address);
        }

    }
}