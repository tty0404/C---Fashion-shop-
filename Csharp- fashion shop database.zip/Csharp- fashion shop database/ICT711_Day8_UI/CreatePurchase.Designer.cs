﻿namespace ICT711_Day8_UI
{
    partial class CreatePurchase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            FNameText = new TextBox();
            LNameText = new TextBox();
            PnText = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            EmailText = new TextBox();
            OrderBtn = new Button();
            createBtn = new Button();
            productLstView = new DataGridView();
            DesireAmount = new DataGridViewTextBoxColumn();
            CheckToBuy = new DataGridViewCheckBoxColumn();
            inventoryBindingSource1 = new BindingSource(components);
            AssoComboBox = new ComboBox();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            ((System.ComponentModel.ISupportInitialize)productLstView).BeginInit();
            ((System.ComponentModel.ISupportInitialize)inventoryBindingSource1).BeginInit();
            SuspendLayout();
            // 
            // FNameText
            // 
            FNameText.AcceptsTab = true;
            FNameText.Location = new Point(12, 98);
            FNameText.Margin = new Padding(2);
            FNameText.Name = "FNameText";
            FNameText.Size = new Size(154, 23);
            FNameText.TabIndex = 1;
            // 
            // LNameText
            // 
            LNameText.AcceptsTab = true;
            LNameText.Location = new Point(12, 155);
            LNameText.Margin = new Padding(2);
            LNameText.Name = "LNameText";
            LNameText.Size = new Size(154, 23);
            LNameText.TabIndex = 2;
            // 
            // PnText
            // 
            PnText.AcceptsTab = true;
            PnText.Location = new Point(12, 215);
            PnText.Margin = new Padding(2);
            PnText.Name = "PnText";
            PnText.Size = new Size(154, 23);
            PnText.TabIndex = 3;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 72);
            label1.Margin = new Padding(2, 0, 2, 0);
            label1.Name = "label1";
            label1.Size = new Size(119, 15);
            label1.TabIndex = 4;
            label1.Text = "Enter your First name";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(11, 133);
            label2.Margin = new Padding(2, 0, 2, 0);
            label2.Name = "label2";
            label2.Size = new Size(120, 15);
            label2.TabIndex = 5;
            label2.Text = "Enter your Last Name";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(11, 193);
            label3.Margin = new Padding(2, 0, 2, 0);
            label3.Name = "label3";
            label3.Size = new Size(143, 15);
            label3.TabIndex = 6;
            label3.Text = "Enter your phone number";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(11, 251);
            label4.Margin = new Padding(2, 0, 2, 0);
            label4.Name = "label4";
            label4.Size = new Size(93, 15);
            label4.TabIndex = 7;
            label4.Text = "Enter your email";
            // 
            // EmailText
            // 
            EmailText.AcceptsTab = true;
            EmailText.Location = new Point(11, 268);
            EmailText.Margin = new Padding(2);
            EmailText.Name = "EmailText";
            EmailText.Size = new Size(154, 23);
            EmailText.TabIndex = 4;
            // 
            // OrderBtn
            // 
            OrderBtn.Location = new Point(933, 410);
            OrderBtn.Margin = new Padding(2);
            OrderBtn.Name = "OrderBtn";
            OrderBtn.Size = new Size(78, 32);
            OrderBtn.TabIndex = 9;
            OrderBtn.Text = "Order!";
            OrderBtn.UseVisualStyleBackColor = true;
            OrderBtn.Click += OrderBtn_Click;
            // 
            // createBtn
            // 
            createBtn.Location = new Point(175, 370);
            createBtn.Margin = new Padding(2);
            createBtn.Name = "createBtn";
            createBtn.Size = new Size(78, 32);
            createBtn.TabIndex = 6;
            createBtn.Text = "Create file";
            createBtn.UseVisualStyleBackColor = true;
            createBtn.Click += createBtn_Click;
            // 
            // productLstView
            // 
            productLstView.AutoGenerateColumns = false;
            productLstView.BackgroundColor = SystemColors.Info;
            productLstView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            productLstView.Columns.AddRange(new DataGridViewColumn[] { DesireAmount, CheckToBuy });
            productLstView.DataSource = inventoryBindingSource1;
            productLstView.GridColor = SystemColors.GradientInactiveCaption;
            productLstView.Location = new Point(340, 64);
            productLstView.Margin = new Padding(2);
            productLstView.Name = "productLstView";
            productLstView.RowHeadersWidth = 62;
            productLstView.Size = new Size(671, 333);
            productLstView.TabIndex = 12;
            productLstView.CellContentClick += productLstView_CellContentClick;
            // 
            // DesireAmount
            // 
            DesireAmount.HeaderText = "Desire Quantity";
            DesireAmount.Name = "DesireAmount";
            DesireAmount.Width = 120;
            // 
            // CheckToBuy
            // 
            CheckToBuy.HeaderText = "";
            CheckToBuy.MinimumWidth = 8;
            CheckToBuy.Name = "CheckToBuy";
            CheckToBuy.Width = 30;
            // 
            // inventoryBindingSource1
            // 
            inventoryBindingSource1.DataSource = typeof(ICT711_Day5_classes.Inventory);
            // 
            // AssoComboBox
            // 
            AssoComboBox.FormattingEnabled = true;
            AssoComboBox.Location = new Point(11, 327);
            AssoComboBox.Margin = new Padding(2);
            AssoComboBox.Name = "AssoComboBox";
            AssoComboBox.Size = new Size(129, 23);
            AssoComboBox.TabIndex = 5;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(10, 310);
            label5.Margin = new Padding(2, 0, 2, 0);
            label5.Name = "label5";
            label5.Size = new Size(118, 15);
            label5.TabIndex = 14;
            label5.Text = "Select your Associate";
            // 
            // label6
            // 
            label6.AutoEllipsis = true;
            label6.BackColor = SystemColors.ControlLight;
            label6.Font = new Font("Ink Free", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(12, 9);
            label6.Name = "label6";
            label6.Size = new Size(320, 52);
            label6.TabIndex = 15;
            label6.Text = "Welcome!\r\nCreate a new profile!\r\nEnter your email if you're our existing customer.";
            label6.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            label7.AutoEllipsis = true;
            label7.AutoSize = true;
            label7.Font = new Font("Ink Free", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = SystemColors.InactiveCaptionText;
            label7.Location = new Point(340, 42);
            label7.Name = "label7";
            label7.Size = new Size(180, 19);
            label7.TabIndex = 16;
            label7.Text = "Select your desire items";
            // 
            // CreatePurchase
            // 
            AcceptButton = createBtn;
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlLight;
            ClientSize = new Size(1022, 462);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(AssoComboBox);
            Controls.Add(productLstView);
            Controls.Add(createBtn);
            Controls.Add(OrderBtn);
            Controls.Add(EmailText);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(PnText);
            Controls.Add(LNameText);
            Controls.Add(FNameText);
            Margin = new Padding(2);
            Name = "CreatePurchase";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "CreatePurchase";
            Load += CreatePurchaseForm_Load;
            ((System.ComponentModel.ISupportInitialize)productLstView).EndInit();
            ((System.ComponentModel.ISupportInitialize)inventoryBindingSource1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TextBox FNameText;
        private TextBox LNameText;
        private TextBox PnText;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox EmailText;
        private Button OrderBtn;
        private Button createBtn;
        private DataGridView productLstView;
        private BindingSource inventoryBindingSource1;
        private ComboBox AssoComboBox;
        private Label label5;
        private Label label6;
        private DataGridViewCheckBoxColumn CheckToBuy;

        private Label label7;
        private DataGridViewTextBoxColumn DesireAmount;
    }
}