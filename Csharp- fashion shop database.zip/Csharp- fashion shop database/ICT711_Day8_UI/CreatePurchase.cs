﻿using ICT711_Day5_classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ICT711_Day8_UI
{

    public partial class CreatePurchase : Form
    {
        public Store? myStore;
        public List<Product>? ProductsList;

        public CreatePurchase()
        {
            InitializeComponent();

        }

        private void LoadStoreData()
        {
            Store.AssociatesFileName = "../../../Data/associates_data.json";
            Store.CustomersFileName = "../../../Data/customers_data.json";
            Store.InventoryFileName = "../../../Data/inventory_data.json";
            Store.SalesFileName = "../../../Data/sales_data.json";
            Store.StoreFileName = "../../../Data/store_data.json";
            myStore?.LoadCustomers();
            myStore?.LoadAssociates();
            myStore?.LoadInventory();
            myStore?.LoadSales();
            // Connect inventory as the data source for our data grid
            productLstView.AutoGenerateColumns = true;
            productLstView.DataSource = myStore?.Inventory.Products.ConvertAll(p => (Product)p);
            productLstView.Refresh();

            //Connect associates for comboBox
            AssoComboBox.DataSource = myStore?.Associates.ConvertAll(a => (Associate)a);

            AssoComboBox.DisplayMember = "FName";
            AssoComboBox.ValueMember = "AssociateId";
            AssoComboBox.Refresh();


        }


        private void CreatePurchaseForm_Load(object sender, EventArgs e)
        {   //load the store information
            myStore = Store.CreateStore();
            LoadStoreData();
        }


        //quantity handler
        private Dictionary<Product, int> selectedProducts = new Dictionary<Product, int>();

        private void productLstView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Ensure the click is on a checkbox cell
            if (e.ColumnIndex == productLstView.Columns["CheckToBuy"].Index && e.RowIndex >= 0)
            {
                // Commit edit immediately
                // productLstView.CommitEdit(DataGridViewDataErrorContexts.Commit);
                productLstView.EndEdit();

                //set some handler that we can use from the gridview
                bool isChecked = Convert.ToBoolean(productLstView.Rows[e.RowIndex].Cells["CheckToBuy"].Value);
                var sel_productId = (int)productLstView.Rows[e.RowIndex].Cells["ProductId"].Value;                
                var cellValue = productLstView.Rows[e.RowIndex].Cells["DesireAmount"].Value;
                int enterQuantity;

                

                //check if customer enter non-number
                if (cellValue != null && int.TryParse(cellValue.ToString(), out enterQuantity) && enterQuantity > 0)
                {
                    Product? selectedProduct = myStore?.Inventory.Products.FirstOrDefault(p => p.ProductId == sel_productId);
                    
                    if (isChecked && selectedProduct != null)
                    {

                        if (selectedProduct != null)
                        {
                            if (enterQuantity > 0)
                            {
                                selectedProducts[selectedProduct] = enterQuantity;
                            }

                            else if (!isChecked && selectedProduct != null && selectedProducts.ContainsKey(selectedProduct))
                            {
                                selectedProducts.Remove(selectedProduct);
                            }

                        }
                    }

                }
                else
                {
                    MessageBox.Show("Please enter integer only", "warning", MessageBoxButtons.OK,MessageBoxIcon.Warning);
                }

 
            }


        }



        private void OrderBtn_Click(object sender, EventArgs e)
        {
            
            //setting the info
            string entEmail = EmailText.Text.Trim();
            var exiCustomer = myStore?.Customers.FirstOrDefault(c => c.Email == entEmail);
            int CustId = exiCustomer.CustomerId;
            int AssId = exiCustomer.MainAssociateId;
            SaleStatus status = (SaleStatus)Enum.Parse(typeof(SaleStatus), "1", true);
            int saleId = new Random().Next();
            DateTime date = DateTime.Now;

            //add new sale into database
            Sale sale = new Sale(saleId,date,CustId, AssId, status) ;

            foreach (var selects in selectedProducts)
            {
                    Product select_product = selects.Key;
                    int quan = selects.Value;

                Product? inventoryProduct = (Product?)myStore?.Inventory[select_product.ProductId];
                if (inventoryProduct != null && inventoryProduct.Quantity >= quan && quan >0 )
                {
                    Product productAdding = new Product {

                        ProductId = select_product.ProductId,
                        ProductName = select_product.ProductName,
                        Description = select_product.Description,
                        Price = select_product.Price,
                        Quantity = quan

                    };
                    sale.AddProduct(productAdding,myStore?.Inventory);
                    inventoryProduct.Quantity -= quan;

                }
                else
                {
                    
                    MessageBox.Show($"Not enough inventory for {select_product.ProductName}.", "Inventory Issue", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return; // Stop processing the sale
                }

            }
               
         
                   myStore?.Sales.Add(sale);
                   MessageBox.Show($"Order placed successfully!\nSale ID: {sale.Id}   Amount: {sale.GetTotal()}\nThank you for your order!", "Order Confirmation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                   //Save sale & inventory data to database                   
                   myStore?.SaveInventory();               
                   myStore?.SaveSales();
            

        }

        private int CustIdGenerator() { 
        
            if (myStore?.Customers != null && myStore.Customers.Any())
            {
                return myStore.Customers.Max(c => c.CustomerId) + 1;
            }
            else
            {
                return 1;
            }
        }


        private void createBtn_Click(object sender, EventArgs e)
        {

            string entEmail = EmailText.Text.Trim();
            var exiCustomer = myStore?.Customers.FirstOrDefault(c => c.Email == entEmail);

            var selectedAss = AssoComboBox.SelectedItem as Associate;
            var selectedName = selectedAss?.FName;

            if (exiCustomer != null)
            {
                FNameText.Text = exiCustomer.FName;
                LNameText.Text = exiCustomer.LName;
                PnText.Text = exiCustomer.Tel;
                EmailText.Text = exiCustomer.Email;

                var asToSel = myStore?.Associates.FirstOrDefault(a => a.AssociateId == exiCustomer.MainAssociateId);
                AssoComboBox.SelectedIndex = AssoComboBox.Items.IndexOf(asToSel);

                MessageBox.Show($"Welcome back \nDear {exiCustomer.FName}\nCust Id: {exiCustomer.CustomerId}\nAssociate: {asToSel?.FName} \nPlease continue to order section!");

            }
            else
            {

                //check the inputs
                if (string.IsNullOrWhiteSpace(FNameText.Text) ||
                    string.IsNullOrWhiteSpace(LNameText.Text) ||
                    string.IsNullOrWhiteSpace(PnText.Text) ||
                    string.IsNullOrWhiteSpace(EmailText.Text))
                {
                    MessageBox.Show("Please enter all your information", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                else
                {
                    string fname = FNameText.Text;
                    string lname = LNameText.Text;
                    string tel = PnText.Text;
                    string email = EmailText.Text;
                    int customerId = CustIdGenerator();                                       
                    int associateId =selectedAss.AssociateId;

                        //create a new customer
                        Customer newCustomer = new Customer(customerId, fname, lname, tel, email)
                        {
                            //set the mainAssociatedId to current selection
                            MainAssociateId = associateId

                        };
                    myStore?.Customers.Add(newCustomer);

                    //save the data in to database
                    myStore?.SaveCustomers();
                    MessageBox.Show($"Welcome to AAA,\nDear {fname}.\nYour Profile is: \nCust Id: {customerId}\nName: {fname} {lname} \nTele: {tel}\nEmail: {email} \nYour Associate : {selectedName}\nPlease continue to order section!", "Successful!");
                

                    
                }



            }


        }

    }

   
}
