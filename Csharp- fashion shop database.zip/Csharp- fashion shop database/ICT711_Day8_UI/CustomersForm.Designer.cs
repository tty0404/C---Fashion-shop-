﻿namespace ICT711_Day8_UI
{
    partial class CustomersForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            customersGrid = new DataGridView();
            customerIdDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            fNameDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            lNameDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            telDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            emailDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            registeredOnDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            customerBindingSource = new BindingSource(components);
            linkLabel1 = new LinkLabel();
            purchaseGridView = new DataGridView();
            detailBtns = new DataGridViewButtonColumn();
            label1 = new Label();
            AssociateLbl = new Label();
            saveBtn = new Button();
            createBtn = new Button();
            CheckInvenBtn = new Button();
            ((System.ComponentModel.ISupportInitialize)customersGrid).BeginInit();
            ((System.ComponentModel.ISupportInitialize)customerBindingSource).BeginInit();
            ((System.ComponentModel.ISupportInitialize)purchaseGridView).BeginInit();
            SuspendLayout();
            // 
            // customersGrid
            // 
            customersGrid.AutoGenerateColumns = false;
            customersGrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            customersGrid.Columns.AddRange(new DataGridViewColumn[] { customerIdDataGridViewTextBoxColumn, fNameDataGridViewTextBoxColumn, lNameDataGridViewTextBoxColumn, telDataGridViewTextBoxColumn, emailDataGridViewTextBoxColumn, registeredOnDataGridViewTextBoxColumn });
            customersGrid.DataSource = customerBindingSource;
            customersGrid.Location = new Point(12, 12);
            customersGrid.Name = "customersGrid";
            customersGrid.RowHeadersWidth = 62;
            customersGrid.Size = new Size(776, 201);
            customersGrid.TabIndex = 0;
            customersGrid.DataError += customersGrid_DataError;
            customersGrid.SelectionChanged += customersGrid_SelectionChanged;
            // 
            // customerIdDataGridViewTextBoxColumn
            // 
            customerIdDataGridViewTextBoxColumn.DataPropertyName = "CustomerId";
            customerIdDataGridViewTextBoxColumn.HeaderText = "ID";
            customerIdDataGridViewTextBoxColumn.MinimumWidth = 8;
            customerIdDataGridViewTextBoxColumn.Name = "customerIdDataGridViewTextBoxColumn";
            customerIdDataGridViewTextBoxColumn.ReadOnly = true;
            customerIdDataGridViewTextBoxColumn.Width = 150;
            // 
            // fNameDataGridViewTextBoxColumn
            // 
            fNameDataGridViewTextBoxColumn.DataPropertyName = "FName";
            fNameDataGridViewTextBoxColumn.HeaderText = "First Name";
            fNameDataGridViewTextBoxColumn.MinimumWidth = 8;
            fNameDataGridViewTextBoxColumn.Name = "fNameDataGridViewTextBoxColumn";
            fNameDataGridViewTextBoxColumn.Width = 150;
            // 
            // lNameDataGridViewTextBoxColumn
            // 
            lNameDataGridViewTextBoxColumn.DataPropertyName = "LName";
            lNameDataGridViewTextBoxColumn.HeaderText = "Last Name";
            lNameDataGridViewTextBoxColumn.MinimumWidth = 8;
            lNameDataGridViewTextBoxColumn.Name = "lNameDataGridViewTextBoxColumn";
            lNameDataGridViewTextBoxColumn.Width = 150;
            // 
            // telDataGridViewTextBoxColumn
            // 
            telDataGridViewTextBoxColumn.DataPropertyName = "Tel";
            telDataGridViewTextBoxColumn.HeaderText = "Tel";
            telDataGridViewTextBoxColumn.MinimumWidth = 8;
            telDataGridViewTextBoxColumn.Name = "telDataGridViewTextBoxColumn";
            telDataGridViewTextBoxColumn.Width = 150;
            // 
            // emailDataGridViewTextBoxColumn
            // 
            emailDataGridViewTextBoxColumn.DataPropertyName = "Email";
            emailDataGridViewTextBoxColumn.HeaderText = "Email";
            emailDataGridViewTextBoxColumn.MinimumWidth = 8;
            emailDataGridViewTextBoxColumn.Name = "emailDataGridViewTextBoxColumn";
            emailDataGridViewTextBoxColumn.Width = 150;
            // 
            // registeredOnDataGridViewTextBoxColumn
            // 
            registeredOnDataGridViewTextBoxColumn.DataPropertyName = "RegisteredOn";
            registeredOnDataGridViewTextBoxColumn.HeaderText = "Registered On";
            registeredOnDataGridViewTextBoxColumn.MinimumWidth = 8;
            registeredOnDataGridViewTextBoxColumn.Name = "registeredOnDataGridViewTextBoxColumn";
            registeredOnDataGridViewTextBoxColumn.ReadOnly = true;
            registeredOnDataGridViewTextBoxColumn.Width = 120;
            // 
            // customerBindingSource
            // 
            customerBindingSource.DataSource = typeof(ICT711_Day5_classes.Customer);
            // 
            // linkLabel1
            // 
            linkLabel1.AutoSize = true;
            linkLabel1.Location = new Point(77, 415);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(10, 15);
            linkLabel1.TabIndex = 1;
            linkLabel1.TabStop = true;
            linkLabel1.Text = ".";
            linkLabel1.LinkClicked += linkLabel1_LinkClicked;
            // 
            // purchaseGridView
            // 
            purchaseGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            purchaseGridView.Columns.AddRange(new DataGridViewColumn[] { detailBtns });
            purchaseGridView.Location = new Point(12, 247);
            purchaseGridView.Name = "purchaseGridView";
            purchaseGridView.RowHeadersWidth = 62;
            purchaseGridView.Size = new Size(523, 142);
            purchaseGridView.TabIndex = 2;
            purchaseGridView.CellContentClick += purchaseGridView_CellContentClick;
            // 
            // detailBtns
            // 
            detailBtns.HeaderText = "";
            detailBtns.MinimumWidth = 8;
            detailBtns.Name = "detailBtns";
            detailBtns.Text = "Details";
            detailBtns.UseColumnTextForButtonValue = true;
            detailBtns.Width = 150;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 229);
            label1.Name = "label1";
            label1.Size = new Size(110, 15);
            label1.TabIndex = 3;
            label1.Text = "Costumer Purchase";
            // 
            // AssociateLbl
            // 
            AssociateLbl.AutoSize = true;
            AssociateLbl.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            AssociateLbl.Location = new Point(12, 415);
            AssociateLbl.Name = "AssociateLbl";
            AssociateLbl.Size = new Size(59, 15);
            AssociateLbl.TabIndex = 4;
            AssociateLbl.Text = "Associate";
            // 
            // saveBtn
            // 
            saveBtn.Location = new Point(666, 404);
            saveBtn.Name = "saveBtn";
            saveBtn.Size = new Size(96, 34);
            saveBtn.TabIndex = 5;
            saveBtn.Text = "&Save";
            saveBtn.UseVisualStyleBackColor = true;
            saveBtn.Click += saveBtn_Click;
            // 
            // createBtn
            // 
            createBtn.Location = new Point(601, 261);
            createBtn.Margin = new Padding(2);
            createBtn.Name = "createBtn";
            createBtn.Size = new Size(161, 29);
            createBtn.TabIndex = 6;
            createBtn.Text = "Create Order";
            createBtn.UseVisualStyleBackColor = true;
            createBtn.Click += createBtn_Click;
            // 
            // CheckInvenBtn
            // 
            CheckInvenBtn.Location = new Point(603, 304);
            CheckInvenBtn.Name = "CheckInvenBtn";
            CheckInvenBtn.Size = new Size(159, 27);
            CheckInvenBtn.TabIndex = 7;
            CheckInvenBtn.Text = "Check Inventory";
            CheckInvenBtn.UseVisualStyleBackColor = true;
            CheckInvenBtn.Click += CheckInvenBtn_Click;
            // 
            // CustomersForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(CheckInvenBtn);
            Controls.Add(createBtn);
            Controls.Add(saveBtn);
            Controls.Add(AssociateLbl);
            Controls.Add(label1);
            Controls.Add(purchaseGridView);
            Controls.Add(linkLabel1);
            Controls.Add(customersGrid);
            Name = "CustomersForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Customers";
            Load += CustomersForm_Load;
            ((System.ComponentModel.ISupportInitialize)customersGrid).EndInit();
            ((System.ComponentModel.ISupportInitialize)customerBindingSource).EndInit();
            ((System.ComponentModel.ISupportInitialize)purchaseGridView).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView customersGrid;
        private BindingSource customerBindingSource;
        private LinkLabel linkLabel1;
        private DataGridView purchaseGridView;
        private Label label1;
        private Label AssociateLbl;
        private DataGridViewButtonColumn detailBtns;
        private DataGridViewTextBoxColumn customerIdDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn fNameDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn lNameDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn telDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn emailDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn registeredOnDataGridViewTextBoxColumn;
        private Button saveBtn;
        private Button createBtn;
        private Button CheckInvenBtn;
    }
}