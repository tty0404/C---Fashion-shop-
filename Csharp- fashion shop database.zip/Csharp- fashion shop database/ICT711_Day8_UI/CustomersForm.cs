﻿using ICT711_Day5_classes;
using Newtonsoft.Json.Bson;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ICT711_Day8_UI
{
    public partial class CustomersForm : Form
    {
        private Store? myStore;
        public Customer? selectedCustomer = null;

        public CustomersForm()
        {
            InitializeComponent();
        }

        private void LoadStoreData()
        {
            Store.AssociatesFileName = "../../../Data/associates_data.json";
            Store.CustomersFileName = "../../../Data/customers_data.json";
            Store.InventoryFileName = "../../../Data/inventory_data.json";
            Store.SalesFileName = "../../../Data/sales_data.json";
            Store.StoreFileName = "../../../Data/store_data.json";
            myStore?.LoadCustomers();
            myStore?.LoadAssociates();
            myStore?.LoadInventory();
            myStore?.LoadSales();
            // Connect the Customer list as the data source for our data grid
            customersGrid.DataSource =
                 myStore?.Customers.ConvertAll(c => (Customer)c);
            
        }

        private void CustomersForm_Load(object sender, EventArgs e)
        {   //load the store information
            myStore = Store.CreateStore();
            LoadStoreData();
        }

        class SaleViewModel //to show only the needed purchase data
        {
            public int Id;
            public DateTime Date { get; set; }
            public decimal Total { get; set; }
        }
        public void RefreshCustGrid()
        {
            myStore?.LoadCustomers(); // Reload or refresh the customer list from the source
            customersGrid.DataSource = null; // Clear 
            customersGrid.DataSource = myStore?.Customers; // Re-bind 
        }


        private void customersGrid_SelectionChanged(object sender, EventArgs e)
        {
            selectedCustomer = (Customer)((DataGridView)sender).CurrentRow.DataBoundItem;
            if (selectedCustomer is null) return;   // Make sure there is a current selection
            linkLabel1.Text = selectedCustomer.GetAssociate(myStore?.Associates);

            // I can show all Sale information 
            //purchasesGridView.DataSource = selectedCustomer.GetPurchases(myStore.Sales)
            //        .ConvertAll(s => (Sale)s);

            // OR: I can show all Sale information in a SaleViewModel form to calculate the Total
            purchaseGridView.DataSource = selectedCustomer.GetPurchases(myStore?.Sales)
                            .ConvertAll(s => new SaleViewModel { Id = s.Id, Date = s.Date, Total = s.GetTotal() });
        }

        private void purchaseGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            var grid = (DataGridView)sender;

            if (e.RowIndex < 0) //They clicked the header column, do nothing                         
                return;


            if (grid[e.ColumnIndex, e.RowIndex] is DataGridViewButtonCell)
            {
                var salev = (SaleViewModel)grid.Rows[e.RowIndex].DataBoundItem;
                Sale? sale = (Sale?)myStore?.Sales.Find(s => s.Id == salev.Id);
                SaleForm sf = new SaleForm();
                sf.SelectedSale = sale;
                sf.myStore = myStore;
                sf?.ShowDialog();
                //MessageBox.Show($"ID-{sale.Id}: {sale.Status}, {sale.Date}", "Sale");

            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (selectedCustomer is null) return;
            int associateID = selectedCustomer.MainAssociateId;

            //get associate information
            Associate? associate = (Associate?)myStore?.Associates.Find(a => a.AssociateId == associateID);

            //show info
            MessageBox.Show($"{associate?.AssociateId}: {associate?.GetFullName()}\n" +
                $"{associate?.Department}\n{associate?.Email}\n{associate?.Tel}", "Customer Associate");
        }

        private void customersGrid_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            //exception handler
            MessageBox.Show(e.Exception?.Message, "Data Entry Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void saveBtn_Click(object sender, EventArgs e)
        {
            myStore?.SaveAssociates();
            myStore?.SaveCustomers();
            myStore?.SaveInventory();
            myStore?.SaveSales();
            myStore?.SaveStoreInfo();

        }

        private void createBtn_Click(object sender, EventArgs e)
        {
            CreatePurchase cp = new CreatePurchase();
            cp.myStore = this.myStore;
            var dialogResult = cp.ShowDialog();
            if (dialogResult == DialogResult.OK)
            {
                RefreshCustGrid();
            }
            cp.Show();
        }

        private void CheckInvenBtn_Click(object sender, EventArgs e)
        {
            productDetail pd = new productDetail();
            pd.myStore = this.myStore;
            pd.Show();
        }
    }
}