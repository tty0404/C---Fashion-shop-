﻿namespace ICT711_Day8_UI
{
    partial class Hello
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            helloBtn = new Button();
            UsernameTxt = new TextBox();
            label1 = new Label();
            outputLbl = new Label();
            SuspendLayout();
            // 
            // helloBtn
            // 
            helloBtn.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            helloBtn.ForeColor = Color.DarkRed;
            helloBtn.Location = new Point(392, 73);
            helloBtn.Name = "helloBtn";
            helloBtn.Size = new Size(75, 55);
            helloBtn.TabIndex = 0;
            helloBtn.Text = "Hello";
            helloBtn.UseVisualStyleBackColor = true;
            helloBtn.Click += helloBtn_Click;
            // 
            // UsernameTxt
            // 
            UsernameTxt.Location = new Point(173, 73);
            UsernameTxt.Name = "UsernameTxt";
            UsernameTxt.PlaceholderText = "Your Name";
            UsernameTxt.Size = new Size(163, 25);
            UsernameTxt.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(29, 76);
            label1.Name = "label1";
            label1.Size = new Size(123, 17);
            label1.TabIndex = 2;
            label1.Text = "What is your name?";
            // 
            // outputLbl
            // 
            outputLbl.AutoSize = true;
            outputLbl.Location = new Point(173, 142);
            outputLbl.Name = "outputLbl";
            outputLbl.Size = new Size(23, 17);
            outputLbl.TabIndex = 3;
            outputLbl.Text = "---";
            // 
            // Hello
            // 
            AutoScaleDimensions = new SizeF(7F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(509, 310);
            Controls.Add(outputLbl);
            Controls.Add(label1);
            Controls.Add(UsernameTxt);
            Controls.Add(helloBtn);
            Name = "Hello";
            Text = "Hello";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button helloBtn;
        private TextBox UsernameTxt;
        private Label label1;
        private Label outputLbl;
    }
}