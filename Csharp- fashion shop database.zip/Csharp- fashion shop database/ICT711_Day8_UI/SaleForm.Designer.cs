﻿
namespace ICT711_Day8_UI
{
    partial class SaleForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            label1 = new Label();
            label2 = new Label();
            customerIDLbl = new Label();
            saleDateLbl = new Label();
            label5 = new Label();
            label6 = new Label();
            associateLbl = new Label();
            totalLbl = new Label();
            label3 = new Label();
            customerNameLbl = new Label();
            okBtn = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            dataGridView1.BackgroundColor = SystemColors.ActiveCaption;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.GridColor = SystemColors.Highlight;
            dataGridView1.Location = new Point(12, 77);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowTemplate.Height = 27;
            dataGridView1.Size = new Size(776, 308);
            dataGridView1.TabIndex = 0;          
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label1.Location = new Point(21, 9);
            label1.Name = "label1";
            label1.Size = new Size(77, 15);
            label1.TabIndex = 1;
            label1.Text = "Customer ID";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label2.Location = new Point(21, 42);
            label2.Name = "label2";
            label2.Size = new Size(60, 15);
            label2.TabIndex = 2;
            label2.Text = "Sale Date";
            // 
            // customerIDLbl
            // 
            customerIDLbl.AutoSize = true;
            customerIDLbl.Location = new Point(116, 9);
            customerIDLbl.Name = "customerIDLbl";
            customerIDLbl.Size = new Size(10, 15);
            customerIDLbl.TabIndex = 3;
            customerIDLbl.Text = ".";
            // 
            // saleDateLbl
            // 
            saleDateLbl.AutoSize = true;
            saleDateLbl.Location = new Point(116, 42);
            saleDateLbl.Name = "saleDateLbl";
            saleDateLbl.Size = new Size(10, 15);
            saleDateLbl.TabIndex = 4;
            saleDateLbl.Text = ".";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label5.Location = new Point(551, 42);
            label5.Name = "label5";
            label5.Size = new Size(34, 15);
            label5.TabIndex = 3;
            label5.Text = "Total";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label6.Location = new Point(288, 42);
            label6.Name = "label6";
            label6.Size = new Size(59, 15);
            label6.TabIndex = 3;
            label6.Text = "Associate";
            // 
            // associateLbl
            // 
            associateLbl.AutoSize = true;
            associateLbl.Location = new Point(373, 42);
            associateLbl.Name = "associateLbl";
            associateLbl.Size = new Size(10, 15);
            associateLbl.TabIndex = 3;
            associateLbl.Text = ".";
            // 
            // totalLbl
            // 
            totalLbl.AutoSize = true;
            totalLbl.Location = new Point(636, 42);
            totalLbl.Name = "totalLbl";
            totalLbl.Size = new Size(10, 15);
            totalLbl.TabIndex = 3;
            totalLbl.Text = ".";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label3.Location = new Point(288, 9);
            label3.Name = "label3";
            label3.Size = new Size(61, 15);
            label3.TabIndex = 3;
            label3.Text = "Customer";
            // 
            // customerNameLbl
            // 
            customerNameLbl.AutoSize = true;
            customerNameLbl.Location = new Point(373, 9);
            customerNameLbl.Name = "customerNameLbl";
            customerNameLbl.Size = new Size(10, 15);
            customerNameLbl.TabIndex = 3;
            customerNameLbl.Text = ".";
            // 
            // okBtn
            // 
            okBtn.Location = new Point(696, 38);
            okBtn.Name = "okBtn";
            okBtn.Size = new Size(75, 23);
            okBtn.TabIndex = 5;
            okBtn.Text = "&OK";
            okBtn.UseVisualStyleBackColor = true;
            okBtn.Click += okBtn_Click;
            // 
            // SaleForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.MenuHighlight;
            ClientSize = new Size(800, 397);
            Controls.Add(okBtn);
            Controls.Add(saleDateLbl);
            Controls.Add(customerNameLbl);
            Controls.Add(totalLbl);
            Controls.Add(associateLbl);
            Controls.Add(label6);
            Controls.Add(label3);
            Controls.Add(label5);
            Controls.Add(customerIDLbl);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(dataGridView1);
            Name = "SaleForm";
            Text = "Sale";
            Load += Sale_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label customerIDLbl;
        private System.Windows.Forms.Label saleDateLbl;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label associateLbl;
        private System.Windows.Forms.Label totalLbl;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label customerNameLbl;
        private Button okBtn;
    }
}