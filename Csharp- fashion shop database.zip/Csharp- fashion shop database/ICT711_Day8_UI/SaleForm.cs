﻿using ICT711_Day5_classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ICT711_Day8_UI
{
    public partial class SaleForm : Form
    {
        public Store? myStore { get; set; }
        public Sale? SelectedSale { get; set; }
        
        public SaleForm()
        {
            InitializeComponent();
        }

        private void Sale_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = SelectedSale?.ProductsList;
            var customer = myStore?.Customers.First(c => c?.CustomerId == SelectedSale?.CustomerId);
            customerIDLbl.Text = customer?.CustomerId.ToString();
            customerNameLbl.Text = customer?.GetFullName();
            associateLbl.Text = customer?.GetAssociate(myStore?.Associates);
            saleDateLbl.Text = SelectedSale?.Date.ToString();
            totalLbl.Text = SelectedSale?.GetTotal().ToString("C2");
        }


        private void okBtn_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
        }





    }

}
    
    

