﻿using ICT711_Day5_classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ICT711_Day8_UI
{
    public partial class productDetail : Form
    {

        public Store? myStore { get; set; }
        public Sale? SelectedSale { get; set; }

        public productDetail()
        {
            InitializeComponent();
        }

        private void LoadStoreData()
        {
            Store.InventoryFileName = "../../../Data/inventory_data.json";
            Store.StoreFileName = "../../../Data/store_data.json";
            myStore?.LoadInventory();

            // Connect inventory as the data source for our data grid
            dataGridView1.AutoGenerateColumns = true;
            dataGridView1.DataSource = myStore?.Inventory.Products.ConvertAll(p => (Product)p);
            dataGridView1.Refresh();




        }

        private void productDetail_Load(object sender, EventArgs e)
        {
            //load the store information
            myStore = Store.CreateStore();
            LoadStoreData();
        }

        private void searchText_TextChanged(object sender, EventArgs e)
        {
            if (myStore?.Inventory?.Products == null) return;

            string searchKeyword = searchText.Text.ToLower();


            var filter = myStore.Inventory.Products
                .Where(p => p.ProductName.ToLower().Contains(searchKeyword))
                .ToList();


            var displayList = filter.ConvertAll(p => (Product)p);

            // reload again
            dataGridView1.DataSource = displayList;
            dataGridView1.Refresh();
        }

        private void searchText_Enter(object sender, EventArgs e)
        {
            TextBox? textBox = sender as TextBox;
            if (textBox != null) {
                searchText.Text = "";
            };
        }
    }
}
