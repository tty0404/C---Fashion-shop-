# ict711i-001 assignments
## ICT711 Computer Programming Level 2 With UofC Continued Education 
### Copyright @2024 Mostafa Mohamed
Please don't share.
